<?php                                                                                          
/* smarty plugin function that gets called when the                                            
load_checkout_info function plugin is loaded from a template */                                
function smarty_function_load_checkout_info($params, $smarty)                                  
{                                                                                              
  $checkout_info = new CheckoutInfo();                                                         
  $checkout_info->init();                                                                      
  // assign template variable                                                                  
  $smarty->assign($params['assign'], $checkout_info);                                          
}                                                                                              
// class that supports the checkout page                                                       
class CheckoutInfo                                                                             
{                                                                                              
  // public attributes                                                                         
  public $mShoppingCartItems;                                                                  
  public $mTotalAmountLabel;                                                                   
  public $mLblCreditCardNote;                                                                  
  public $mEditShoppingCart = "index.php?CartAction";                                          
  public $mOrderButtonVisible;                                                                 
  public $mNoShippingAddress = "no";                                                           
  public $mContinueShopping;                                                                   
  public $mPlainCreditCard;                                                                    
  // private attributes                                                                        
  private $mPlaceOrder = 0;                                                                    
  // constructor                                                                               
  function __construct()                                                                       
  {                                                                                            
    $this->mBoCustomer = new BoCustomer();                                                     
    if (isset($_POST['sended'])) $this->mPlaceOrder=1;                                         
  }                                                                                            
  // init                                                                                      
  public function init()                                                                       
  {                                                                                            
    // create business tier object                                                             
    $cart = new BoShoppingCart();                                                              
    // if the Place Order button was clicked, save the order to database                       
    if ($this->mPlaceOrder == 1)         
    {                                    
       // Create the order and store the order ID 
       $order_id=$cart->CreateOrder();   
       // Get configuration for order processor
       $processor_configuration = new OrderProcessorConfiguration
                                        (ADMIN_EMAIL,
                                        $GLOBALS['admin_email_params'],
                                        CUSTOMER_SERVICE_EMAIL,
                                        $GLOBALS['customer_service_email_params'],
                                        ORDER_PROCESSOR_EMAIL,
                                        $GLOBALS['order_processor_email_params'],
                                        SUPPLIER_EMAIL,PAYFLOW_PRO_PARTNER,    
                                        PAYFLOW_PRO_HOST,PAYFLOW_PRO_USER,PAYFLOW_PRO_PWD);   
       // Create new OrderProcessor instance
       $processor = new OrderProcessor();
       try                               
       {                                 
         $processor->Process($order_id, $processor_configuration);
       }                                 
       catch (Exception $e)              
       {                                 
         // If an error occurs, head to an error page   
         header("Location: checkout.php?OrderError");
         exit;                           
       }                                              
       // On success head to an order successful page              
       header("Location:checkout.php?OrderDone");     
       exit;                                          
    }                                                                                     
    // set members for use in the Smarty template
    $this->mShoppingCartItems=$cart->GetCartProducts(GET_CART_PRODUCTS);
    $this->mTotalAmountLabel = $cart->GetTotalAmount(); 
    $this->mContinueShopping = $_SESSION['PageLink'];
    $this->mCustomerData = $this->mBoCustomer->GetCurrentCustomer();
    // we allow placing orders only if we have complete customer details
    if (empty($this->mCustomerData))   
    {                                  
       header("Location:checkout.php");
       exit;                           
    }                                  
    if (empty($this->mCustomerData['credit_card'])) 
    {                                  
       $this->mLblCreditCardNote = "No credit card details stored."; 
       $this->mOrderButtonVisible = "disabled='disabled'";
    }                                  
    else                               
    {                                  
       $this->mPlainCreditCard = $this->mBoCustomer->DecryptCreditCard(
                                      $this->mCustomerData['credit_card']);
       $this->mLblCreditCardNote = "Credit card to use: " 
                                    . $this->mPlainCreditCard->mCardType 
                                    . ". Card number: " 
                                    . $this->mPlainCreditCard->mCardNumberX;
    }                                  
    if (empty($this->mCustomerData['address1'])) 
    {                                  
       $this->mOrderButtonVisible = "disabled";
       $this->mNoShippingAddress = "yes";
    }                                  
  }                                    
}//end class                           
?>              