              <?php                           
              class PsTakePayment implements IPipelineSection 
              {                               
                 public function Process($processor)
                 {                            
                   $processor->AddAudit("PSTakePayment started.", 20400);
                   $transaction =             
                      array('USER'    => $processor->mConfiguration->mPayflowProUser, //username
                             'PWD'     => $processor->mConfiguration->mPayflowProPwd, // password
                             'PARTNER' => 'VeriSign', // Partner 
                             'TRXTYPE' => 'D', // Type Delayed Capture 
                             'TENDER'  => 'C', // Credit Card 
                             'ORIGID' => $processor->GetReference());
                   $response =                
                        pfpro_process($transaction,$processor->mConfiguration->mPayflowProHost);
                   if ($response['RESULT']==0) 
                   {                          
                     $processor->AddAudit("Funds deducted from customer credit card.", 20403);
                     $processor->UpdateOrderStatus(5);
                     $processor->mContinueNow=true;
                   }                                                                
                   else                                                             
                   {                                                                
                     $processor->AddAudit("Error taking funds from credit card.", 20403); 
                     ob_start();                                                    
                     var_dump($transaction);                                        
                     var_dump($response);                                           
                     $response_dump = ob_get_contents();                            
                     ob_end_clean();                                                
                     throw new Exception("Credit card take payment failed for order ".
                                             $processor->mOrderId. ".\n\n" .        
                                             "Data exchanged:" . $transaction . "\n" . 
                                             $response_dump);                       
                   }                                                                
                   $processor->UpdateOrderStatus(5);                                
                   $processor->mContinueNow = true;                                 
                   $processor->AddAudit("PSTakePayment finished.",20401);           
                }                                                                   
              }                                                                     
              ?>              