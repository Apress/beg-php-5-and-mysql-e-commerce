<?php                                                                 
              class PsCheckFunds implements IPipelineSection                        
              {                                                                     
                 public function Process($processor)                                
                 {                                                                  
                   $processor->AddAudit("PSCheckFunds started.", 20100);            
                   $currentCustomer = $processor->GetCurrentCustomer();             
                   $currentOrderDetails = $processor->GetCurrentOrderDetails();     
                   $exp_date = str_replace("/", "" ,                                
                                              $currentCustomer->mCreditCard->GetExpiryDate());
                   $transaction =                                                   
                     array('USER'    => $processor->mConfiguration->mPayflowProUser, // username 
                            'PWD'     => $processor->mConfiguration->mPayflowProPwd, // password 
                            'PARTNER' => 'VeriSign', // Partner                     
                            'TRXTYPE' => 'A', // Type Authorize                     
                            'TENDER'  => 'C', // Credit Card                        
                            'AMT'     => $currentOrderDetails->mTotalCost, // Amount to charge 
                            'ACCT'    => $currentCustomer->mCreditCard->GetCardNumber(), // CC # 
                            'EXPDATE' => $exp_date, // Expiry (MMYY)                
                            'INVNUM'  => ($processor->mOrderId + 1000000));         
                   $response =                                                      
                       pfpro_process($transaction,$processor->mConfiguration->mPayflowProHost);
                   if ($response['RESULT']==0) 
                   {                          
                     $reference = $response['PNREF'];
                     $auth_code = $response['AUTHCODE'];
                     $processor->SetOrderAuthCodeAndReference($auth_code, $reference);
                     $processor->AddAudit("Funds available for purchase.", 20102);
                     $processor->UpdateOrderStatus(2);
                     $processor->mContinueNow = true;
                   }                          
                   else                       
                   {                          
                     $processor->AddAudit("Funds not available for purchase.", 20103);
                     ob_start();              
                     var_dump($transaction);  
                     var_dump($response);         
                     $response_dump = ob_get_contents();
                     ob_end_clean();          
                     throw new Exception("Credit card check funds failed for order " . 
                                             $processor->mOrderId . ".\n\n" . 
                                             "Data exchanged:" . $transaction . 
                                             "\n" . $response_dump);
                   }                          
                   $processor->AddAudit("PSCheckFunds finished.", 20101);
                }                             
              } //end class                   
              ?>                   
 