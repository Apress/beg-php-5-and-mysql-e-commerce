<?php                                          
class OrderProcessorConfiguration              
{                                              
  public $mAdminEmail;                         
  public $mAdminEmailParams;                   
  public $mCustomerServiceEmail;               
  public $mCustomerServiceEmailParams;         
  public $mOrderProcessorEmail;                
  public $mOrderProcessorEmailParams;          
  public $mSupplierEmail;     
  public $mPayflowProPartner;                                 
  public $mPayflowProHost;                                    
  public $mPayflowProUser;                                    
  public $mPayflowProPwd;                    
  // constructor initializes class members     
  function __construct($newAdminEmail, $newAdminEmailParams,
    $newCustomerServiceEmail, $newCustomerServiceEmailParams,
    $newOrderProcessorEmail, $newOrderProcessorEmailParams, $newSupplierEmail,
    $newPayflowProPartner,$newPayflowProHost,$newPayflowProUser,$newPayflowProPwd)
  {                                            
    $this->mAdminEmail = $newAdminEmail;       
    $this->mAdminEmailParams = $newAdminEmailParams;
    $this->mCustomerServiceEmail = $newCustomerServiceEmail;
    $this->mCustomerServiceEmailParams = $newCustomerServiceEmailParams;
    $this->mOrderProcessorEmail = $newOrderProcessorEmail;
    $this->mOrderProcessorEmailParams = $newOrderProcessorEmailParams;
    $this->mSupplierEmail = $newSupplierEmail; 
    $this->mPayflowProPartner = $newPayflowProPartner;        
    $this->mPayflowProHost = $newPayflowProHost;              
    $this->mPayflowProUser = $newPayflowProUser;              
    $this->mPayflowProPwd = $newPayflowProPwd;
  }                                            
}                                              
?> 