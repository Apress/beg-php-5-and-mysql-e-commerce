<?php                                                         
class PsTakePayment implements IPipelineSection               
{                                                             
  public function Process( $processor)                        
  {                                                           
    $processor->AddAudit("PSTakePayment started.",20400);     
    $request = new DataCashRequest($processor->mConfiguration->mDataCashUrl);
    $request->MakeXmlFulfill($processor->mConfiguration->mDataCashClient,
                                 $processor->mConfiguration->mDataCashPwd,
                                 "fulfill",                   
                                 $processor->GetAuthCode(),   
                                 $processor->GetReference()); 
    $responseXML = $request->GetResponse();                   
    $xml = simplexml_load_string($responseXML);                                      
    if ($xml->status == 1)                                                           
    {                                                                                
       $processor->AddAudit("Funds deducted from customer credit card.",             
                               20403);                                               
       $processor->UpdateOrderStatus(5);                                             
       $processor->mContinueNow = true;                                              
    }                                                                                
    else                                                                             
    {                                                                                
       $processor->AddAudit("Could not deduct funds from credit card.",              
                               20403);                                               
       throw new Exception("Credit card take payment failed for order ".             
                               $processor->mOrderId. ".\n\n" .                       
                               "Data exchanged:\n" .                                 
                               $request->GetRequest() . "\n" . $responseXML);        
    }                                                                                
    $processor->UpdateOrderStatus(5);                                                
    $processor->mContinueNow = true;                                                 
    $processor->AddAudit("PSTakePayment finished.", 20401);                          
  }                                                                                  
}                                                                                    
?>  