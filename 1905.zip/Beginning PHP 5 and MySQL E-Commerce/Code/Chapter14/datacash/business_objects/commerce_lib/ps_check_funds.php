<?php                                                           
class PsCheckFunds implements IPipelineSection                  
{                                                               
  public function Process($processor)                           
  {                                                             
    $processor->AddAudit("PSCheckFunds started.",20100);        
    $currentCustomer = $processor->GetCurrentCustomer();        
    $currentOrderDetails = $processor->GetCurrentOrderDetails();
    $request = new DataCashRequest($processor->mConfiguration->mDataCashUrl);
    $request->MakeXmlPre($processor->mConfiguration->mDataCashClient,
                            $processor->mConfiguration->mDataCashPwd,
                            $processor->mOrderId+1000006,     
                            $currentOrderDetails->mTotalCost, 
                            "GBP",                            
                            "pre",                            
                            $currentCustomer->mCreditCard->GetCardNumber(),
                            $currentCustomer->mCreditCard->GetExpiryDate(),
                            $currentCustomer->mCreditCard->GetIssueDate(),
                            $currentCustomer->mCreditCard->GetIssueNumber());

    $responseXML = $request->GetResponse();                   
    $xml = simplexml_load_string($responseXML);               
    if ($xml->status == 1)                                    
    {                                                         
       $processor->SetOrderAuthCodeAndReference($xml->merchantreference,
                                                     $xml->datacash_reference);
       $processor->AddAudit("Funds available for purchase.", 20102);
       $processor->UpdateOrderStatus(2);                      
       $processor->mContinueNow = true;                       
    }                                                         
    else                                                      
    {                     
       $processor->AddAudit("Funds not available for purchase.", 20103); 
       throw new Exception("Credit card check funds failed for order " . 
                               $processor->mOrderId . ".\n\n" .
                                "Data exchanged:\n" .         
                                $request->GetRequest(). "\n". $responseXML);
    }                                                         
    $processor->AddAudit("PSCheckFunds finished.", 20101);    
  }                                                           
} //end class                                                 
?>    