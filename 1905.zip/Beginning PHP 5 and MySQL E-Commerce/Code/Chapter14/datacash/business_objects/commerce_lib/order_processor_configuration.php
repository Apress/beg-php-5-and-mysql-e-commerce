<?php                                          
class OrderProcessorConfiguration              
{                                              
  public $mAdminEmail;                         
  public $mAdminEmailParams;                   
  public $mCustomerServiceEmail;               
  public $mCustomerServiceEmailParams;         
  public $mOrderProcessorEmail;                
  public $mOrderProcessorEmailParams;          
  public $mSupplierEmail;         
  public $mDataCashClient;                                    
  public $mDataCashPwd;                                       
  public $mDataCashUrl;                  
  // constructor initializes class members     
  function __construct($newAdminEmail, $newAdminEmailParams,
    $newCustomerServiceEmail, $newCustomerServiceEmailParams,
    $newOrderProcessorEmail, $newOrderProcessorEmailParams, $newSupplierEmail,
    $newDataCashUrl, $newDataCashClient, $newDataCashPwd)   
  {                                            
    $this->mAdminEmail = $newAdminEmail;       
    $this->mAdminEmailParams = $newAdminEmailParams;
    $this->mCustomerServiceEmail = $newCustomerServiceEmail;
    $this->mCustomerServiceEmailParams = $newCustomerServiceEmailParams;
    $this->mOrderProcessorEmail = $newOrderProcessorEmail;
    $this->mOrderProcessorEmailParams = $newOrderProcessorEmailParams;
    $this->mSupplierEmail = $newSupplierEmail; 
    $this->mDataCashUrl=$newDataCashUrl;                      
    $this->mDataCashClient=$newDataCashClient;                
    $this->mDataCashPwd=$newDataCashPwd;     
  }                                            
}                                              
?> 