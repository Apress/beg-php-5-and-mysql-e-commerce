<?php                                                                                  
class DataCashRequest                                                                  
{                                                                                      
  // DataCash Server URL                                                               
  private $mUrl;                                                                       
  // Will hold the current XML document to be sent to DataCash                         
  private $mXml;                                                                       
  // constructor initializes the class with URL of DataCash                            
  function __construct($url)                                                           
  {                                                                                    
    //Datacash URL                                                                     
    $this->mUrl = $url;                                                                
  }                                                                                    
  // compose the XML structure for the pre-authentication request to DataCash
  public function MakeXmlPre($dataCashClient,                 
                                 $dataCashPassword,           
                                 $merchantReference,          
                                 $amount,                     
                                 $currency,                   
                                 $method,                     
                                 $cardNumber,                 
                                 $expiryDate,                 
                                 $startDate = "",             
                                 $issueNumber = "")           
  {                                                           
    $this->mXml =                                             
          "<?xml version=\"1.0\" encoding=\"UTF-8\"\x3F>      
           <Request>                                          
           <Authentication>                                   
              <password>$dataCashPassword</password>          
              <client>$dataCashClient</client>                
           </Authentication>                                  
           <Transaction>                                      
           <TxnDetails>                                       
            <merchantreference>$merchantReference</merchantreference>
            <amount currency='$currency'>$amount</amount>     
           </TxnDetails>                                      
           <CardTxn>                                          
            <method>pre</method>                              
            <Card>                                            
              <pan>$cardNumber</pan>                          
              <expirydate>$expiryDate</expirydate>            
              <startdate>$startDate</startdate>               
              <issuenumber>$issueNumber</issuenumber>         
            </Card>                                           
           </CardTxn>                                         
          </Transaction>                                      
          </Request>";                                        
  }                                                           
  // Compose the XML structure for the fulfillment request to DataCash
  public function MakeXmlFulfill($dataCashClient,             
                                     $dataCashPassword,       
                                     $method,                 
                                     $authCode,               
                                     $reference)              
  {             
    $this->mXml =
          "<?xml version=\"1.0\" encoding=\"UTF-8\"\x3F>
           <Request>
            <Authentication>
              <password>$dataCashPassword</password>
              <client>$dataCashClient</client>
            </Authentication>
            <Transaction>
              <HistoricTxn>
               <reference>$reference</reference>
               <authcode>$authCode</authcode>
               <method>$method</method>
              </HistoricTxn>
            </Transaction>
           </Request>";
  }             
  // get the current XML
  public function GetRequest()
  {             
    return $this->mXml;
  }             
  // send an HTTP POST request to DataCash using CURL
  public function GetResponse()
  {             
    // initialize a CURL session
    $ch = curl_init();
    // prepare for an HTTP POST request
    curl_setopt($ch, CURLOPT_POST, 1);
    // prepare the XML document to be POSTed
    curl_setopt($ch, CURLOPT_POSTFIELDS,$this->mXml);
    // set the URL where we want to POST our XML structure
    curl_setopt($ch, CURLOPT_URL, $this->mUrl);
    // do not verify the Common name of the peer certificate in the SSL
    // handshake
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    // prevent CURL from verifying the peer's certificate
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    // we want CURL to directly return the transfer instead of
    // printing it
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    // perform a CURL session
    $result = curl_exec($ch);
    // close a CURL session
    curl_close ($ch);
    // return the response                                    
    return $result;                                           
  }                                                           
}//end class                                                  
?>   