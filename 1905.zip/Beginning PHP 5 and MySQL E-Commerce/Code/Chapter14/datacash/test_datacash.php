<?php                                                         
session_start();                                              
if (empty($_GET['step']))                                     
{                                                             
  require_once 'include/config.inc.php';                      
  require_once DATACASH_DIR . 'datacash_request.php';         
  $data_cash_url = "https://testserver.datacash.com/Transaction";
  $data_cash_client = "99265300";                             
  $data_cash_password = "4SXmkzM8h";                          
  $request = new DataCashRequest($data_cash_url);             
  $request->MakeXmlPre($data_cash_client,                     
                          $data_cash_password,                
                          8880000+rand(0,10000),              
                          49.99,                              
                          "GBP",                              
                          "pre",                              
                          "3528000000000007",                 
                          "11/05");                           
  $request_xml = $request->GetRequest();                      
  $_SESSION['pre_request'] = $request_xml;                    
  $response_xml = $request->GetResponse();                    
  $_SESSION['pre_response'] = $response_xml;                  
  $xml = simplexml_load_string($response_xml);                
  $request->MakeXmlFulfill($data_cash_client,                 
                               $data_cash_password,           
                               "fulfill",                     
                               $xml->merchantreference,       
                               $xml->datacash_reference);     
  $response_xml = $request->GetResponse();                    
  $_SESSION['fulfill_response'] = $response_xml;              
}                                                             
else                                                          
{                                                             
  header('Content-type: text/xml');                           
  switch ($_GET['step'])                                      
    {   
    case 1:
       print $_SESSION['pre_request'];
       break;
    case 2:
       print $_SESSION['pre_response'];
       break;
    case 3:
       print $_SESSION['fulfill_response'];
       break;
   }    
  exit; 
}       
?>      
<frameset cols="33%, 33%, 33%">
<frame src="test_datacash.php?step=1">
<frame src="test_datacash.php?step=2">
<frame src="test_datacash.php?step=3">
</frameset>
