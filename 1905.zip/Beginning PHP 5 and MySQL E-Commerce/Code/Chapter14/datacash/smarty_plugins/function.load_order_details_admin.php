<?php                                                         
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_order_details_admin($params, $smarty)
{                                                             
  $order_details_admin = new OrderDetailsAdmin();             
  $order_details_admin->init();                               
  // assign template variable                                 
  $smarty->assign($params['assign'], $order_details_admin);   
}                                                             
// presentation tier class that deals with administering order details
class OrderDetailsAdmin                                       
{                                                             
  /* public variables avaible in smarty template */           
  public $mOrderId;                                           
  public $mOrderInfo;                                         
  public $mOrderDetails;                                      
  public $mCustomerDetails;                                   
  public $mAudit;                                             
  public $mErrorLabel = "";                                   
  public $mProcessButtonText;                                 
  /* private stuff */                                         
  private $mOrderManager;                                     
  function __construct()                                      
  {                                                           
     $this->mOrderManager = new BoOrderManager();             
     // we receive the order ID in the query string           
     $this->mOrderId = (int)$_GET['OrderId'];                 
  }                                                           
  function init()                                             
  {                                                           
     if (empty($_GET['OrderId']))                             
       trigger_error("OrderId parameter is required", E_USER_ERROR);
     // we check order ID to be integer                       
     if ((string)(int)$_GET['OrderId'] == (string)$_GET['OrderId'])
       $this->mOrderId = (int)$_GET['OrderId'];               
     else                                                     
     {                                                        
       $this->mErrorLabel = $_GET['OrderId']." is not integer";
       return ;                                               
     }                                                        
     if (isset($_GET['process']))
     {                 
       // Get configuration for order processor
       $processor_configuration = new OrderProcessorConfiguration(
                      ADMIN_EMAIL,
                      $GLOBALS['admin_email_params'], 
                      CUSTOMER_SERVICE_EMAIL,
                      $GLOBALS['customer_service_email_params'], 
                      ORDER_PROCESSOR_EMAIL,
                      $GLOBALS['order_processor_email_params'], 
                      SUPPLIER_EMAIL,DATACASH_URL,DATACASH_CLIENT,
                      DATACASH_PWD);
       $processor = new OrderProcessor();
       try             
       {               
         $processor->Process($this->mOrderId, $processor_configuration);
       }               
       catch (Exception $e) 
       {               
         echo $e->getMessage();
         exit;         
       }               
     }                 
     $this->PopulatePage();
  }                    
  public function PopulatePage()
  {                    
     /* SECTION 1 */   
     $this->mOrderInfo = $this->mOrderManager->GetOrder($this->mOrderId);
     if (empty($this->mOrderInfo))
       $this->mErrorLabel = $this->mOrderId." is not a valid order id";
     // Name or hide Process button
     if ($this->mOrderInfo['status'] == 3)
       $this->mProcessButtonText = "Confirm Stock";
     elseif ($this->mOrderInfo['status'] == 6)
       $this->mProcessButtonText = "Confirm Shipment";
     /* get data for SECTION 2 table */
     $this->mOrderDetails = 
         $this->mOrderManager->GetOrderDetails($this->mOrderId);
     /* get data for SECTION 3 table */
     $this->mCustomerDetails = 
         $this->mOrderManager->GetCustomerByOrderID($this->mOrderId);
     /* get data for SECTION 4 table */
     $this->mAudit =   
         $this->mOrderManager->GetAuditTrail($this->mOrderId);
  }                    
} //end class          
?>                     


