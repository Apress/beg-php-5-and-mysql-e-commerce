<?php                                                               
// Reference config files and business tier                         
require_once 'include/app_top.php';                                 
require_once SITE_ROOT . '/business_objects/bo_shopping_cart.php';  
// If admin is already logged, redirect to the requested page       
if (!isset($_SESSION['AdminLogged']) || !$_SESSION['AdminLogged'])  
{                                                                   
  header('Location: admin_login.php?ReturnPage=cart_admin.php');    
  exit;                                                             
}                                                                   
// If logging out ...                                               
if (isset($_GET['Page']) && $_GET['Page'] == "Logout")              
{                                                                   
  unset($_SESSION['AdminLogged']);                                  
  header("Location: index.php");                                    
  exit;                                                             
}                                                                   
$message = "";                                                      
$selected = 1;                                                      
if (isset($_GET['days']))                                           
{                                                                   
  $shopping_cart = new BoShoppingCart();                            
  $affected = $shopping_cart->DeleteOldShoppingCarts((int)$_GET['days']);
   $message = "You deleted " . $affected .                          
                " carts older than {$_GET['days']} days.";          
  $selected=(int)$_GET['days'];                                     
}                                                                   
// Load the page                                                    
$page = new Page();                                                 
$page->assign('days_ids', array(1,3,5,10,15,30));                   
$page->assign('message', $message);                                 
$page->assign('selected', $selected);                               
$page->display('cart_admin.tpl');                                   
// Load app_bottom which closes the database connection             
require_once 'include/app_bottom.php';                              
?>                                                                  
