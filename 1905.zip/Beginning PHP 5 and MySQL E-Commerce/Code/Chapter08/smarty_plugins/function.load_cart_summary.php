<?php                                                               
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_cart_summary($params, $smarty)        
{                                                                   
  $cart_summary = new CartSummary();                                
  // assign template variable                                       
  $smarty->assign($params['assign'], $cart_summary);                
}                                                                   
// class that deals with managing the shopping cart summary         
class CartSummary                                                   
{                                                                   
  public $mTotalAmount;                                             
  public $mItems;                                                   
  function __construct()                                            
  {                                                                 
    // creating the middle tier object                              
    $shopping_cart = new BoShoppingCart();                          
    // calculate the total amount for the shopping cart             
    $this->mTotalAmount = $shopping_cart->GetTotalAmount();         
    // get shopping cart products                                   
    $this->mItems =                                                 
        $shopping_cart->GetCartProducts(GET_CART_PRODUCTS);         
    if (empty($this->mItems))                                                                   
       $this->mEmptyCart = true;                               
    else                                                       
       $this->mEmptyCart = false;                              
  }                                                            
}                                                              
?>           