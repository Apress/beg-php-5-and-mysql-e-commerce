<?php                                                          
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_shopping_cart($params, $smarty)  
{                                                              
  $shopping_cart = new ShoppingCart();                         
  $shopping_cart->init();                                      
  // assign template variable                                  
  $smarty->assign($params['assign'], $shopping_cart);          
}                                                              
// class that deals with managing the shopping cart            
class ShoppingCart                                             
{                                                              
  /* public variables available in smarty template */          
  public $mShoppingCartProducts;                               
  public $mSavedShoppingCartProducts;                          
  public $mTotalAmount;                                        
  public $mIsCartNowEmpty = 0; // is the shopping cart empty?  
  public $mIsCartLaterEmpty = 0; // is the 'saved for later' list empty?
  public $mShoppingCartReferrer = "index.php";                      
  /* private attributes */                                          
  private $mShoppingCart;                                           
  private $mProductId;                                              
  private $mShoppingCartAction;                                     
  //class constructor                                               
  function __construct()                                            
  {                                                                 
    //setting the "Continue shopping" button target                 
    if (isset($_SESSION['PageLink']))                               
       $this->mShoppingCartReferrer = $_SESSION['PageLink'];        
    // creating the middle tier object                              
    $this->mShoppingCart = new BoShoppingCart();                    
    if (isset($_GET['CartAction']))                                 
       $this->mShoppingCartAction = $_GET['CartAction'];            
    else                                                            
       trigger_error("CartAction not set", E_USER_ERROR);           
    // these cart operations require a valid product id             
    if ($this->mShoppingCartAction == ADD_PRODUCT ||                
         $this->mShoppingCartAction == REMOVE_PRODUCT ||            
         $this->mShoppingCartAction == SAVE_PRODUCT_FOR_LATER ||    
         $this->mShoppingCartAction == MOVE_PRODUCT_TO_CART)        
       if (isset($_GET['ProductID']))                               
         $this->mProductId = $_GET['ProductID'];                    
       else                                                         
         trigger_error("ProductID must be set for this type of request", 
E_USER_ERROR);                                                      
   }                                                                
   //init                                                           
   function init()                                                  
   {                                                                
      switch ($this->mShoppingCartAction)                           
      {                                                             
        case ADD_PRODUCT:                                           
          $this->mShoppingCart->AddProduct($this->mProductId);      
          header("Location: $this->mShoppingCartReferrer");         
          break;                                                    
      case REMOVE_PRODUCT:                                          
          $this->mShoppingCart->RemoveProduct($this->mProductId);   
          break;                                                    
        case UPDATE_PRODUCTS_QUANTITIES:                            
          $this->mShoppingCart->Update($_POST['productID'],         
                                           $_POST['quantity']);     
          break;                                                    
        case SAVE_PRODUCT_FOR_LATER:                                
          $this->mShoppingCart->SaveProductToBuyLater($this->mProductId);
          break;
        case MOVE_PRODUCT_TO_CART:
          $this->mShoppingCart->MoveProductToCart($this->mProductId);
          break;
        default:
          // do nothing
          break;
    }      
    // calculate the total amount for the shopping cart
    $this->mTotalAmount = $this->mShoppingCart->GetTotalAmount();
    // get shopping cart products
    $this->mShoppingCartProducts = 
          $this->mShoppingCart->GetCartProducts(GET_CART_PRODUCTS);
    // gets the 'saved for later' products
    $this->mSavedShoppingCartProducts =        
          $this->mShoppingCart->GetCartProducts(GET_CART_SAVED_PRODUCTS);
    // check whether we have an empty shopping cart
    if (count($this->mShoppingCartProducts) == 0) 
       $this->mIsCartNowEmpty = 1;
    // check whether we have an empty 'saved for later' list
    if (count($this->mSavedShoppingCartProducts) == 0) 
       $this->mIsCartLaterEmpty = 1;
  }        
} //end class
?>        