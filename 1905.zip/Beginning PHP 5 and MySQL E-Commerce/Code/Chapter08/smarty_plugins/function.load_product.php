<?php                                             
// plugin function for the load_product function plugin
function smarty_function_load_product($params, $smarty)
{                                                 
  $product = new Product();                       
  $product->init();                               
  // assign template variable                     
  $smarty->assign($params['assign'], $product);   
}                                                 
// class that handles product details             
class Product                                     
{                                                 
  // public variables to be used in Smarty template 
  public $mProduct;                               
  public $mPageLink = "index.php";
  // private stuff 
  private $mBoCatalog;
  private $mProductId;
  // class constructor
  function __construct()
  {          
    // create the middle tier object
    $this->mBoCatalog = new BoCatalog();
    // variable initialization
    if (isset($_GET['ProductID']))
       $this->mProductId = (int)$_GET['ProductID'];
    else     
       trigger_error("ProductID required in product.php");
  }          
  // init    
  function init()
  {          
    // get product details from business tier 
    $this->mProduct = 
       $this->mBoCatalog->GetProductDetails($this->mProductId);
    if (isset($_SESSION['PageLink'])) 
       $this->mPageLink = $_SESSION['PageLink'];
    $this->mAddToCartLink = "index.php?CartAction=" . ADD_PRODUCT . 
                   "&ProductID=" . $this->mProductId;

  }          
} //end class
?>           
