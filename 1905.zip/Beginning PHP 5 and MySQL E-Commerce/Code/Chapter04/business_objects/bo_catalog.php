<?php                                                     
// reference the data tier                                
require_once SITE_ROOT.'/data_objects/do_catalog.php';    
// business tier class for reading products catalog information
class BoCatalog                                           
{                                                         
  /* private stuff */                                    
  private $mDoCatalog;                                   
  // class constructor initializes the data tier object  
  function __construct()                                 
  {                                                      
    $this->mDoCatalog = new DoCatalog();                 
  }                                                      
  // retrieves all departments                           
  public function GetDepartments()                       
  {                                                      
    $result = $this->mDoCatalog->GetDepartments();       
    return $result;                                      
  }                                                      
  // retrieves complete details for the specified department
  public function GetDepartmentDetails($departmentId)    
  {                                                      
    $result = $this->mDoCatalog->GetDepartmentDetails($departmentId);
    return $result;
  }            
  // retrieves list of categories that belong to a department
  public function GetCategoriesInDepartment($departmentId)
  {            
     $result = $this->mDoCatalog->GetCategoriesInDepartment($departmentId);
     return $result;
  }            
  // retrieves complete details for the specified category
  public function GetCategoryDetails($categoryId)
  {            
     $result = $this->mDoCatalog->GetCategoryDetails($categoryId);
     return $result;
  }            
  // retrieves list of products that belong to a category
  public function GetProductsInCategory($categoryId, $pageNo, &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
     if (empty($pageNo)) $pageNo=1;
     // call data tier method to obtain the list of products
     $result = $this->mDoCatalog->GetProductsInCategory($categoryId, $pageNo,
       $rTotalPages);
     // return results
     return $result;
  }            
  // retrieves list of products that are on promotion for a department
  public function GetProductsOnDepartmentPromotion($departmentId, $pageNo,
     &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
     if (empty($pageNo)) $pageNo=1;
     // call data tier method to obtain the list of products
     $result = $this->mDoCatalog->GetProductsOnDepartmentPromotion
       ($departmentId, $pageNo, $rTotalPages);
     // return results
     return $result;
  }            
  // retrieves list of products to be featured in the first page of the catalog
  public function GetProductsOnCatalogPromotion($pageNo, &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
    if (empty($pageNo)) $pageNo=1;                       
    // call data tier method to obtain the list of products
    $result = $this->mDoCatalog->GetProductsOnCatalogPromotion($pageNo,
      $rTotalPages);                                     
    // return results                                    
    return $result;                                      
  }                                                       
  // retrieves complete product details                     
  public function GetProductDetails($productId)           
  {                                                       
     $result = $this->mDoCatalog->GetProductDetails($productId);
     return $result;                                      
  }                                                       
}                                                         
//end BoCatalog                                           
?>                                             