<?php                                             
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_department($params, $smarty)
{                                                 
  $department = new Department();                 
  $department->init();                            
  // assign template variable                     
  $smarty->assign($params['assign'], $department);
}                                                 
// class that deals with retrieving department details
class Department                                  
{                                                 
  /* public variables for the smarty template */  
  public $mDescriptionLabel;                      
  public $mNameLabel;                           

  /* private members */
  private $mBoCatalog;
  private $mDepartmentId;
  private $mCategoryId;
  /* constructor */
  function __construct()
  {            
    // create instance of business tier object
    $this->mBoCatalog = new BoCatalog();
    // we need to have DepartmentID in the query string
    if (isset($_GET['DepartmentID']))
       $this->mDepartmentId = (int)$_GET['DepartmentID'];
    else       
       trigger_error("DepartmentID not set");
    // if CategoryID is in the query string we save it 
    // (casting it to integer to protect against invalid values)
    if (isset($_GET['CategoryID']))
       $this->mCategoryId = (int)$_GET['CategoryID'];
  }            
  /* init */   
  function init()
  {            
    // if visiting a department ...
    $details = 
          $this->mBoCatalog->GetDepartmentDetails($this->mDepartmentId);
    $this->mNameLabel = $details['name'];
    $this->mDescriptionLabel = $details['description'];
    // if visiting a category ...
    if (isset($this->mCategoryId))
    {          
       $details = 
              $this->mBoCatalog->GetCategoryDetails($this->mCategoryId);
       $this->mNameLabel = 
              $this->mNameLabel . " >> " . $details['category_name'];
       $this->mDescriptionLabel = $details['category_description'];
    }          
  }            
}              
?>             

