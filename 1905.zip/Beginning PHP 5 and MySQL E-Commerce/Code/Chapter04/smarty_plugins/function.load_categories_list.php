<?php        
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_categories_list($params, $smarty)
{            
  $categories_list = new CategoriesList();
  $categories_list->init();
  // assign template variable
  $smarty->assign($params['assign'], $categories_list);
}            
// class that manages the categories list 
class CategoriesList
{            
  /* public variables for the smarty template */
  public $mCategorySelected = 0;
  public $mDepartmentSelected = 0;
  public $mCategories;                            
  /* private members */                           
  private $mBoCatalog;                            
  /* constructor */                               
  function __construct()                          
  {                                               
    $this->mBoCatalog = new BoCatalog();          
    if (isset($_GET['DepartmentID']))             
       $this->mDepartmentSelected = (int)$_GET['DepartmentID'];
    else                                          
       trigger_error("DepartmentID not set");     
    if (isset($_GET['CategoryID']))               
       $this->mCategorySelected = (int)$_GET['CategoryID'];
  }                                               
  /* init */                                      
  function init()                                 
  {                                               
    $this->mCategories =                          
    $this->mBoCatalog->GetCategoriesInDepartment($this->mDepartmentSelected);
// building links for the category pages          
    for ($i = 0; $i < count($this->mCategories); $i++)
       $this->mCategories[$i]['onclick'] =        
           "index.php?DepartmentID=" .            
           $this->mDepartmentSelected . "&CategoryID=" . 
           $this->mCategories[$i]['category_id']; 
  }                                               
} //end class                                     
?>     