<?php                                                            
// Load Smarty library and config files                          
require_once 'include/app_top.php';                              
// Load the page                                                 
$page = new Page();                                              
$admin_login = new AdminLogin();                                 
$page->assign_by_ref("admin_login", $admin_login);               
$page->display('admin_login.tpl');                               
// app_bottom closes database connection and flushes output buffering
require_once 'include/app_bottom.php';                           
// class that deals with authenticating administrators           
class AdminLogin                                                 
{                                                                
  // public variables available in smarty template               
  public $mUsername;                                             
  public $mLoginMessage = "";                                    
  public $mReturnPage;                                           
  // class constructor                                           
  function __construct()                                         
  {                                                              
    // page the user is forwarded to in case the password is correct
    if (isset($_GET['ReturnPage']))                              
       $this->mReturnPage = $_GET['ReturnPage'];                 
    // If admin is already logged, redirect to the requested page
    if (isset($_SESSION['AdminLogged'])                          
         && $_SESSION['AdminLogged'] ==  true)                   
    {                                                            
       header('Location: ' . $this->mReturnPage);                
       exit;                                                     
    }                                                            
    // verify if the correct username and password have been supplied
    if(isset($_POST['Submit']))                                  
    {                                                            
       if($_POST['username'] == ADMIN_USERNAME                   
          && $_POST['password'] == ADMIN_PASSWORD)               
       {                                                         
         $_SESSION['AdminLogged'] = true;                        
         header("Location: " . $this->mReturnPage);              
         exit;                                                   
       }                                                         
       else                                                      
         $this->mLoginMessage = "<br />Login failed. Please try again:";
    }                                                            
  }                                                              
}                                                                
?>               