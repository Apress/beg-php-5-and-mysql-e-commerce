<?php  
// data tier class
class DoCatalog 
{      
  // class constructor
  function __construct()
  {    
    // get the global DbManager instance (created in app_top.php)
    $this->dbManager = $GLOBALS['gDbManager'];
  }    
  // retrieves all departments
  public function GetDepartments()
  {    
    $query_string = "SELECT department_id, name FROM department";
    $result = $this->dbManager->DbGetAll($query_string);
    return $result;
  }    
  // retrieves all details for the mentioned department
  public function GetDepartmentDetails($departmentId)
  {                      
    $query_string = "SELECT name, description
                     FROM department
                     WHERE department_id = $departmentId";
    $result = $this->dbManager->DbGetRow($query_string);
    return $result;     
  }     
  // retrieves categories that belong to the mentioned department
  public function GetCategoriesInDepartment($departmentId)
  {                                                      
    $query_string = "SELECT category_id, name            
                     FROM category                     
                     WHERE department_id = $departmentId";
    $result = $this->dbManager->DbGetAll($query_string);                         
    return $result;                                      
  }    
  // retrieves details about the mentioned category      
  public function GetCategoryDetails($categoryId)        
  {                                                      
    $query_string =                                      
              "SELECT name AS category_name, description AS category_description
               FROM category                                     
               WHERE category_id = $categoryId";                 
    $result = $this->dbManager->DbGetRow($query_string); 
    return $result;                                      
  }            
  // counts how many records are returned by a SELECT command                       
  private function CountQueryRecords($queryString)                                  
  {                                                                                 
     // test if $queryString is a valid SELECT query                                
     if (strtoupper(substr($queryString, 0, 6)) != 'SELECT')                        
       trigger_error("Not a SELECT statement");                                     
     $from_position = stripos($queryString, "FROM ");                               
     if ($from_position == false)                                                   
       trigger_error("Bad SELECT statement");                                       
     // if the previous call to CountQueryRecords had the same SELECT string        
     // as parameter, we return directly the cached response                        
     if (isset($_SESSION['last_count_query']))                                      
       if ($_SESSION['last_count_query'] == $queryString)                           
         return $_SESSION['last_count'];                                            
     // calculate the number of records the SELECT query returns                    
     $count_query = "SELECT COUNT(*) ".substr($queryString, $from_position);        
     $items_count = $this->dbManager->DbGetOne($count_query);                       
     // save the query and its record count in the session                          
     $_SESSION['last_count_query'] = $queryString;                                  
     $_SESSION['last_count'] = $items_count;                                        
     // return the calculated number of records
     return $items_count;
  }            
  // alters a SQL query to return only the specified page of products
  private function CreateSubpageQuery($queryString, $pageNo, &$rTotalPages)
  {                                                      
    // calculate number of records returned by the SELECT query
    $items_count = $this->CountQueryRecords($queryString);
    // if we have few products then we don't implement pagination
    if ($items_count <= PRODUCTS_PER_PAGE)               
    {                                                    
      $pageNo = 1;                                       
      $rTotalPages = 1;                                  
    }                                                    
    // else we calculate number of pages and the new SELECT query
    else                                                 
    {                                                    
      $rTotalPages = ceil($items_count / PRODUCTS_PER_PAGE);
      $start_page = ($pageNo - 1) * PRODUCTS_PER_PAGE;   
      $queryString .= " LIMIT " . $start_page . "," . PRODUCTS_PER_PAGE;
    }                                                    
    return $queryString;                                 
  }         
  // retrieves a list of products that belong to the specified category
  public function GetProductsInCategory($categoryId, $pageNo, &$rTotalPages)
  {           
    $query_string = 
      "SELECT product.product_id, product.name,
         CONCAT(LEFT(description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."), '...')
            AS description,
         product.price, product.image_file_1,
         product.on_department_promotion, product.on_catalog_promotion
       FROM product INNER JOIN product_category
       ON product.product_id = product_category.product_id
       WHERE product_category.category_id = $categoryId";
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);
  }   
  // retrieves the products that are on promotion for the specified department
  public function GetProductsOnDepartmentPromotion($departmentId, $pageNo,
    &$rTotalPages)                                       
  {                                                      
    $query_string =                                      
        "SELECT DISTINCT product.product_id, product.name,
            CONCAT(LEFT(product.description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."),
             '...') AS description,                      
            product.price, product.image_file_1          
         FROM product                                    
         INNER JOIN product_category                     
            ON product.product_id = product_category.product_id
         INNER JOIN category                             
            ON product_category.category_id = category.category_id
         WHERE product.on_department_promotion = 1       
            AND category.department_id=$departmentId";   
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);      
  }   
  // retrieves the list of products on catalog promotion
  public function GetProductsOnCatalogPromotion($pageNo, &$rTotalPages)
  {             
    $query_string = 
      "SELECT   
         product.product_id, product.name,
            CONCAT(LEFT(description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."), '...')
            AS description,
         product.price, product.image_file_1
       FROM product
       WHERE product.on_catalog_promotion = 1";
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);
  }             
  // retrieves complete product details
  public function GetProductDetails($productId)
  {             
    $query_string = 
      "SELECT product_id, name, description,
               price, image_file_1, image_file_2
       FROM product
       WHERE product_id = $productId";
    return $this->dbManager->DbGetRow($query_string);
  }             
  // Search product catalog                                                            
  public function Search($words, $allWords, $pageNo, &$rTotalPages)                    
  {                                                                       
     // if $allWords is "on" then we append a "+" to each word in the $words array
     if (strcmp($allWords, "on") == 0)                                    
       for ($i = 0; $i < count($words); $i++)                             
         $words[$i] = "+" . $words[$i];                                   
     // join the $words array to create a single search string            
     $temp_string = $words[0];                                            
     for ($i = 1; $i < count($words); $i++)                               
       $temp_string = $temp_string . " $words[$i]";                       
     // build search query                                                
     if (strcmp($allWords, "on") == 0)                                    
       // build all-words search query                                    
       $query_string = "SELECT product_id, name, CONCAT(LEFT(description,"
                          . SHORT_PRODUCT_DESCRIPTION_LENGTH .            
                         "),'...') AS description, price, image_file_1    
                         FROM product                                     
                         WHERE MATCH (name,description)                   
                         AGAINST (\"$temp_string\" IN BOOLEAN MODE)       
                         ORDER BY MATCH (name,description)                
                         AGAINST (\"$temp_string\" IN BOOLEAN MODE)";     
     else                                                                 
       // built any-words search query                                    
       $query_string = "SELECT product_id, name, CONCAT(LEFT(description,"
                          . SHORT_PRODUCT_DESCRIPTION_LENGTH .            
                         "),'...') AS description, price, image_file_1    
                         FROM product                                     
                         WHERE MATCH (name,description)                   
                            AGAINST (\"$temp_string\")";                  
     // call CreateSubpageQuery to implement paging                       
     $page_query = $this->CreateSubpageQuery($query_string, $pageNo,      
                                                  $rTotalPages);          
     // execute the query and return the results                          
     return $this->dbManager->DbGetAll($page_query);                      
  }                                                                 
  // retrieves all departments with their descriptions                  
  public function GetDepartmentsWithDescriptions()                      
  {                                                                     
    $query_string = "SELECT department_id, name, description FROM department";
    $result = $this->dbManager->DbGetAll($query_string);                
    return $result;                                                     
  }                  
  public function UpdateDepartment($departmentId, $departmentName,      
                                        $departmentDescription)    
  {            
     $query_string =
       "UPDATE department
        SET name = '" . $this->dbManager->DbEscapeSimple($departmentName) .
        "', description = '" .
        $this->dbManager->DbEscapeSimple($departmentDescription) .
        "' WHERE department_id = $departmentId";
     $result = $this->dbManager->DbQuery($query_string);
  }                 
  public function DeleteDepartment($departmentId)
  {           
    $query_string = 
      "SELECT COUNT(*) 
       FROM category WHERE department_id = $departmentId";
    $counter = $this->dbManager->DbGetOne($query_string);
    if ($counter == 0)
    {         
      $query_string = 
        "DELETE FROM department WHERE department_id = $departmentId";
      $result = $this->dbManager->DbQuery($query_string);
      return 1;
    }         
    return -1;
  }           
  // add a department
  public function AddDepartment($departmentName, $departmentDescription)
  {           
    $query_string = 
      "INSERT INTO department (name, description)
       VALUES ('" . $this->dbManager->DbEscapeSimple($departmentName) . 
       "', '" . $this->dbManager->DbEscapeSimple($departmentDescription) 
       . "')";
    $result = $this->dbManager->DbQuery($query_string);
  }           
  public function GetCategoriesInDepartmentWithDescriptions($departmentId)
  {
    $query_string = "SELECT category_id, name, description
                     FROM category
                     WHERE department_id = $departmentId";    
 
    $result=$this->dbManager->DbGetAll($query_string);
    return $result; 
  }
 
  public function AddCategory($departmentId, $categoryName, $categoryDescription)
  {
    $query_string = 
      "INSERT INTO category (department_id,name, description)
       VALUES ($departmentId,'" . 
       $this->dbManager->DbEscapeSimple($categoryName) . "', '" . 
       $this->dbManager->DbEscapeSimple($categoryDescription)."')";
    $result = $this->dbManager->DbQuery($query_string);
  }

  public function DeleteCategory($categoryId)
  {
    $query_string = 
      "SELECT COUNT(*)
       FROM product INNER JOIN product_category 
       ON product.product_id = product_category.product_id 
       WHERE product_category.category_id = $categoryId";
    $counter = $this->dbManager->DbGetOne($query_string);
    if ($counter == 0)
    {    
      $query_string = "DELETE FROM category WHERE category_id = $categoryId";
      $result = $this->dbManager->DbQuery($query_string);
      return 1;
    }
    return -1;
  }

  public function UpdateCategory($categoryId, $categoryName, $categoryDescription)
  {
    $query_string = 
      "UPDATE category SET name = '" . 
       $this->dbManager->DbEscapeSimple($categoryName) . 
       "', description = '" . 
       $this->dbManager->DbEscapeSimple($categoryDescription) . 
       "' WHERE category_id = $categoryId";
    $result=$this->dbManager->DbQuery($query_string);
  }

  public function GetProductsInCategoryAdmin($categoryId)
  {  
    $query_string = 
      "SELECT product.product_id,product.name, product.description,
              product.price, product.image_file_1, image_file_2, 
              product.on_department_promotion, product.on_catalog_promotion
       FROM product INNER JOIN product_category 
       ON product.product_id = product_category.product_id 
       WHERE product_category.category_id = $categoryId";
    $result=$this->dbManager->DbGetAll($query_string);
    return $result; 
  }
 
  public function CreateProductToCategory($categoryId, $productName, $productDescription, $productPrice,$productImage1,$productImage2, $onDepartmentPromotion,$onCatalogPromotion)
  {
    $query_string = 
      "INSERT INTO product (name, description, price, image_file_1, image_file_2, on_department_promotion, on_catalog_promotion)
       VALUES('" . $this->dbManager->DbEscapeSimple($productName) . "','" . $this->dbManager->DbEscapeSimple($productDescription) . "', $productPrice, '$productImage1', '$productImage2', $onDepartmentPromotion, $onCatalogPromotion)"; 
    $this->dbManager->DbQuery($query_string);
    $query_string = "SELECT LAST_INSERT_ID()";  
    $product_id = $this->dbManager->DbGetOne($query_string);
    $query_string = "INSERT INTO product_category(product_id, category_id)
                     VALUES($product_id, $categoryId)";  
    $this->dbManager->DbQuery($query_string);
  }

  public function UpdateProduct($productId, $productName,
                                  $productDescription, $productPrice,
                                  $productImage1,$productImage2, $onDepartmentPromotion,
                                  $onCatalogPromotion)
  {
    $query_string = "UPDATE product
                     SET name = '$productName',
                         description = '".$this->dbManager->DbEscapeSimple($productDescription)."',
                         price = $productPrice,
                         image_file_1 = '$productImage1', 
                         image_file_2 = '$productImage2', 
                         on_department_promotion = $onDepartmentPromotion,
                         on_catalog_promotion = $onCatalogPromotion
                     WHERE product_id = $productId";
    $this->dbManager->DbQuery($query_string);
  }
  public function DeleteProduct($productId)                              
  {                                                                      
     $query_string = "DELETE FROM product_category WHERE product_id = $productId";
     $this->dbManager->DbQuery($query_string);                           
     $query_string = "DELETE FROM product WHERE product_id = $productId";
     $this->dbManager->DbQuery($query_string);                           
  }                                                                                
  public function RemoveProductFromCategory($productId, $categoryId)    
  {                                                                     
    $query_string = "SELECT COUNT(*) FROM product_category              
                       WHERE product_id=$productId";                    
    $counter = $this->dbManager->DbGetOne($query_string);               
    if ($counter == 1)                                                  
    {                                                                   
      $this->DeleteProduct($productId);                                 
      return 0;                                                         
    }                                                                   
    else                                                                
    {                                                                   
      $query_string =                                                   
        "DELETE FROM product_category                                   
         WHERE category_id = $categoryId AND product_id = $productId";  
      $this->dbManager->DbQuery($query_string);                         
      return 1;                                                         
    }                                                                   
  }       
  public function GetCategories()                                        
  {                                                                      
     $query_string = "SELECT category_id, name, description FROM category";
     $result=$this->dbManager->DbGetAll($query_string);                  
     return $result;                                                     
  }                                                                                            
  public function GetCategoriesForProduct($productId)
  {                                           
    $query_string =                           
     "SELECT category.category_id, category.department_id, category.name
      FROM category JOIN product_category     
      ON category.category_id = product_category.category_id
      WHERE product_category.product_id = $productId";
    $result = $this->dbManager->DbGetAll($query_string);
    return $result;                           
  }                                            
  public function AssignProductToCategory($productId, $categoryId)
  {                                           
    $query_string =                           
      "INSERT INTO product_category (product_id, category_id)
       VALUES ($productId, $categoryId)";     
    $this->dbManager->DbQuery($query_string);  
  }                                           
                
  public function MoveProductToCategory($productId, $sourceCategoryId, 
                                             $targetCategoryId)
  {                                           
    $query_string = "UPDATE product_category  
                       SET category_id=$targetCategoryId
                       WHERE product_id = $productId AND
                              category_id = $sourceCategoryId";
    $this->dbManager->DbQuery($query_string); 
  }                                           
  public function SetPicture1($productId, $pictureName)                  
  {                                                                      
     $query_string = "UPDATE product                                     
                        SET image_file_1 = '$pictureName'                
                        WHERE product_id = $productId";                  
     $this->dbManager->DbQuery($query_string);                           
  }                                                                      
  public function SetPicture2($productId, $pictureName)                  
  {                                                                      
     $query_string = "UPDATE product                                     
                        SET image_file_2 = '$pictureName'                
                        WHERE product_id = $productId";                  
     $this->dbManager->DbQuery($query_string);                           
  }         
} //end DoCatalog
?>     
