<?php
/* smarty plugin function that gets called when the
load_admin_categories function plugin is loaded from a template */
function smarty_function_load_admin_categories($params, $smarty)
{

  $admin_categories = new AdminCategories();
  $admin_categories->init();
  // assign template variable
  $smarty->assign($params['assign'], $admin_categories);
}

// class that deals with departments admin
class AdminCategories
{
  // public variables available in smarty template
  public $mCategoriesCount;
  public $mCategories;
  public $mEditItem =  - 1;
  public $mErrorMessage = "";
  public $mDepartmentId;
  public $mDepartmentName;
  /* private members */
  private $mCatalog;
  private $mAction="";
  private $mActionedCategId;
  // class constructor
  function __construct()
  {
    $this->mCatalog = new BoCatalog();
    if (isset($_GET['DepartmentID']))
      $this->mDepartmentId = (int)$_GET['DepartmentID'];
    else
      trigger_error("DepartmentID not set");
    $department_details = $this->mCatalog->GetDepartmentDetails($this
      ->mDepartmentId);
    $this->mDepartmentName = $department_details['name'];
    foreach ($_POST as $key => $value) 
    //if a submit button was clicked..    
    if (substr($key,0,6) == "submit") 
    {       
      /* get the position of the last '_' underscore from submit button name 
         e.g strtpos("submit_edit_dep_1","_") is 16
      */
      $last_underscore = strrpos($key,"_");
      //get the scope of submit button (e.g  'edit_dep' from 'submit_edit_dep_1')
      $this->mAction = substr($key,strlen("submit_"),$last_underscore-strlen("submit_"));        
      /* get the department id targeted by submit button
         (the number at the end of submit button name )
         e.g '1' from 'submit_edit_dep_1'
      */ 
      $this->mActionedCategId = (int)substr($key,$last_underscore+1);       
      break; 
    }
  }
  //init
  function init()
  {
    // if adding a new category ...
    if ($this->mAction == "add")
    {
      $category_name = $_POST['categ_name'];
      $category_description = $_POST['categ_description'];
      if ($category_name == null)
        $this->mErrorMessage = 'Category name is empty';
      if ($this->mErrorMessage == null)
        $this->mCatalog->AddCategory($this->mDepartmentId, $category_name,
          $category_description);
    }
    // if editing an existing department ...
    if ($this->mAction == "edit_categ")
    {
      $this->mEditItem = $this->mActionedCategId;
    }
    // if updating a category ...
    if ($this->mAction == "update")
    {
      $category_name = $_POST['categ_name'];
      $category_description = $_POST['categ_description'];
//      echo $category_description;exit;
      if ($category_name == null)
        $this->mErrorMessage = 'Category name is empty';
      if ($this->mErrorMessage == null)
        $this->mCatalog->UpdateCategory($this->mActionedCategId, $category_name,
          $category_description);
    }
    // if deleting a category ...
    if ($this->mAction == "delete")
    {
      $status = $this->mCatalog->DeleteCategory($this->mActionedCategId);
      if ($status < 0)
        $this->mErrorMessage = "Category not empty";
    }
    // if editing category's products ...
    if ($this->mAction == "edit_products")
    {
      header(
        "Location:catalog_admin.php?Page=Products&DepartmentID=$this->mDepartmentId&CategoryID=$this->mActionedCategId");
      exit;
    }
    $this->mCategories = $this->mCatalog
      ->GetCategoriesInDepartmentWithDescriptions($this->mDepartmentId);
    $this->mCategoriesCount = count($this->mCategories);
  }
}
?>
