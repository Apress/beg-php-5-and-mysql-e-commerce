<?php   
/* smarty plugin function that gets called when the
load_admin_product_details function plugin is loaded from a template */
function smarty_function_load_admin_product_details($params, $smarty)
{       
  $admin_product = new AdminProduct();
  $admin_product->init();
  // assign template variable
  $smarty->assign($params['assign'], $admin_product);
}       
// class that deals with product administration
class AdminProduct
{       
  //public attributes
  public $mProductName;
  public $mProductImage1;
  public $mProductImage2;
  public $mProductCategoriesString;
  public $mRemoveFromCategories;
  public $mProductId;
  public $mCategoryId;
  public $mDepartmentId;
  public $mRemoveFromCategoryButtonDisabled = false;
  //private attributes
  private $mCatalog;
  private $mTargetCategoryId;
  // class constructor
  function __construct()
  {     
    // business tier class
    $this->mCatalog = new BoCatalog();
    // need to have DepartmentID in the query string
    if (!isset($_GET['DepartmentID']))
       trigger_error("DepartmentID not set");
    else
       $this->mDepartmentId = (int)$_GET['DepartmentID'];
    // need to have CategoryID in the query string
    if (!isset($_GET['CategoryID']))
       trigger_error("CategoryID not set");
    else
       $this->mCategoryId = (int)$_GET['CategoryID'];
    // need to have ProductID in the query string
    if (!isset($_GET['ProductID']))
       trigger_error("ProductID not set");
    else                                                         
       $this->mProductId = (int)$_GET['ProductID'];              
  }                                                              
  // init                                                        
  public function init()                                         
  {                                                              
    // if uploading a product picture ...                        
    if (isset($_POST['Upload']))                                 
    {                                                            
       // check whether we have write permission on the product_images folder
       if (!is_writeable(SITE_ROOT . '/product_images/'))        
       {                                                         
         echo "Can't write to the product_images folder";        
         exit;                                                   
       }                                                         
       // if the error code is 0, the first file was uploaded ok 
       if ($_FILES['Image1Upload']['error'] == 0)                
       {                                                         
         // use the move_uploaded_file PHP function to move the file 
         // from its temporary location to the product_images folder
         move_uploaded_file($_FILES['Image1Upload']['tmp_name'], 
           SITE_ROOT . '/product_images/' . $_FILES['Image1Upload']['name']);
         // update the product's information in the database     
         $this->mCatalog->SetPicture1($this->mProductId,         
           $_FILES['Image1Upload']['name']);                     
       }                                                         
       // if the error code is 0, the second file was uploaded ok
       if ($_FILES['Image2Upload']['error'] == 0)                
       {                                                         
         // move the uploaded file to the product_images folder  
         move_uploaded_file($_FILES['Image2Upload']['tmp_name'], 
           SITE_ROOT . '/product_images/' . $_FILES['Image2Upload']['name']);
         // update the product's information in the database     
         $this->mCatalog->SetPicture2($this->mProductId,         
           $_FILES['Image2Upload']['name']);                     
       }                                                         
    }                                                            
    // if removing the product from a category...                
    if (isset($_POST['RemoveFromCategory']))                     
    {                                                            
       $target_category_id = $_POST['TargetCategoryIdRemove'];   
       $still_exists = $this->mCatalog->RemoveProductFromCategory(
                                 $this->mProductId, $target_category_id);
       if ($still_exists == 0)                                   
       {                                                         
         header(                                                 
           "Location:catalog_admin.php?Page=Products&DepartmentID=" . 
           "$this->mDepartmentId&CategoryID=$this->mCategoryId");
         exit;              
       }                    
    }                       
    // if removing the product from catalog...
    if (isset($_POST['RemoveFromCatalog']))
    {                       
       $this->mCatalog->DeleteProduct($this->mProductId);
       header(              
         "Location:catalog_admin.php?Page=Products&DepartmentID=" .
         "$this->mDepartmentId&CategoryID=$this->mCategoryId");
       exit;                
    }                       
    // if assigning the product to another category ...
    if (isset($_POST['Assign']))
    {                       
       $target_category_id = $_POST['TargetCategoryIdAssign'];
       $this->mCatalog->AssignProductToCategory($this->mProductId,
         $target_category_id);      
    }                       
    // if moving the product to another category ...
    if (isset($_POST['Move']))
    {                       
       $target_category_id = $_POST['TargetCategoryIdMove'];
       $this->mCatalog->MoveProductToCategory($this->mProductId,
                           $this->mCategoryId,$target_category_id);
       header(              
         "Location:catalog_admin.php?Page=ProductDetails".
         "&DepartmentID=$this->mDepartmentId&CategoryID=$target_category_id".
         "&ProductID=$this->mProductId");
       exit;                
    }                       
    // get product details and show them to user
    $product_details =      
       $this->mCatalog->GetProductDetails($this->mProductId);
    $this->mProductName = $product_details['name'];
    $this->mProductImage1 = $product_details['image_file_1'];
    $this->mProductImage2 = $product_details['image_file_2'];
    $product_categories =   
       $this->mCatalog->GetCategoriesForProduct($this->mProductId);
    if (count($product_categories) == 1) 
       $this->mRemoveFromCategoryButtonDisabled = true;
    // show the categories the product belongs to
    for ($i = 0; $i < count($product_categories); $i++)
       $temp1[$product_categories[$i]['category_id']] =
         $product_categories[$i]['name'];
    $this->mRemoveFromCategories = $temp1;
    $this->mProductCategoriesString = implode(",", $temp1);      
    $all_categories = $this->mCatalog->GetCategories();          
    for ($i = 0; $i < count($all_categories); $i++)              
       $temp2[$all_categories[$i]['category_id']] =              
$all_categories[$i]['name'];                                     
    $this->mAssignOrMoveTo = array_diff($temp2, $temp1);         
  }                                                              
} //end class                                                    
?>                                                               
