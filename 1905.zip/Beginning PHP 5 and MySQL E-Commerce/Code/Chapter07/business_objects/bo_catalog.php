<?php                                                     
// reference the data tier                                
require_once SITE_ROOT.'/data_objects/do_catalog.php';  
// Class that stores the results of a product catalog search      
class SearchResults                                                
{                                                                 
  public $mProducts; // list of products                          
  public $mSearchedWords; // words used for searching             
  public $mIgnoredWords; // words that were ignored               
}                                             
// business tier class for reading products catalog information
class BoCatalog                                           
{                                                         
  /* private stuff */                                    
  private $mDoCatalog;                                   
  // class constructor initializes the data tier object  
  function __construct()                                 
  {                                                      
    $this->mDoCatalog = new DoCatalog();                 
  }                                                      
  // retrieves all departments                           
  public function GetDepartments()                       
  {                                                      
    $result = $this->mDoCatalog->GetDepartments();       
    return $result;                                      
  }                                                      
  // retrieves complete details for the specified department
  public function GetDepartmentDetails($departmentId)    
  {                                                      
    $result = $this->mDoCatalog->GetDepartmentDetails($departmentId);
    return $result;
  }            
  // retrieves list of categories that belong to a department
  public function GetCategoriesInDepartment($departmentId)
  {            
     $result = $this->mDoCatalog->GetCategoriesInDepartment($departmentId);
     return $result;
  }            
  // retrieves complete details for the specified category
  public function GetCategoryDetails($categoryId)
  {            
     $result = $this->mDoCatalog->GetCategoryDetails($categoryId);
     return $result;
  }            
  // retrieves list of products that belong to a category
  public function GetProductsInCategory($categoryId, $pageNo, &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
     if (empty($pageNo)) $pageNo=1;
     // call data tier method to obtain the list of products
     $result = $this->mDoCatalog->GetProductsInCategory($categoryId, $pageNo,
       $rTotalPages);
     // return results
     return $result;
  }            
  // retrieves list of products that are on promotion for a department
  public function GetProductsOnDepartmentPromotion($departmentId, $pageNo,
     &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
     if (empty($pageNo)) $pageNo=1;
     // call data tier method to obtain the list of products
     $result = $this->mDoCatalog->GetProductsOnDepartmentPromotion
       ($departmentId, $pageNo, $rTotalPages);
     // return results
     return $result;
  }            
  // retrieves list of products to be featured in the first page of the catalog
  public function GetProductsOnCatalogPromotion($pageNo, &$rTotalPages)
  {            
     // make sure we send a valid page number to data tier
    if (empty($pageNo)) $pageNo=1;                       
    // call data tier method to obtain the list of products
    $result = $this->mDoCatalog->GetProductsOnCatalogPromotion($pageNo,
      $rTotalPages);                                     
    // return results                                    
    return $result;                                      
  }                                                       
  // retrieves complete product details                     
  public function GetProductDetails($productId)           
  {                                                       
     $result = $this->mDoCatalog->GetProductDetails($productId);
     return $result;                                      
  }             
  // Search the catalog                                           
  public function Search($searchString, $allWords, $pageNo, &$rTotalPages)
  {                                                               
    // create an instance of SearchResults                        
    $search_results = new SearchResults();                        
    // search string delimiters                                   
    $delimiters = ",.; ";                                         
    /* on the first call to strtok you supply the whole search string 
    and the list of delimiters. It returns the first word of the string */
    $word = strtok($searchString, $delimiters);                   
    $accepted_words = array();                                    
    $ignored_words = array();                                     
    // parse the search string word by word until there are no more words
    while ($word)                                                 
    {                                                             
       // short words are added to the ignored_words lists        
       if (strlen($word) < FT_MIN_WORD_LEN)
         $ignored_words[] = $word;
       else
         $accepted_words[] = $word;
       // get the next word of the search string
       $word = strtok($delimiters);
    }     
    // if there are any accepted words...
    if (count($accepted_words))
    {     
       // get the search results by calling the data tier Search method
       $search_results->mProducts = $this->mDoCatalog->Search
       ($accepted_words, $allWords, $pageNo, $rTotalPages);
    }     
    // save the list of accepted words and ignored words
    if ($accepted_words != null)
       $search_results->mSearchedWords = implode(", ", $accepted_words);
    if ($ignored_words != null) 
       $search_results->mIgnoredWords = implode(", ", $ignored_words);
    // return results
    return $search_results;
  }                       
  // retrieves all departments with their descriptions          
  public function GetDepartmentsWithDescriptions()              
  {                                                             
     $result = $this->mDoCatalog->GetDepartmentsWithDescriptions();
     return $result;                                            
  }                                                             
  // updates department details                                 
  public function UpdateDepartment($departmentId, $departmentName, 
                                                         $departmentDescription)
  {                                                             
     $this->mDoCatalog->UpdateDepartment($departmentId, $departmentName, 
                                                               $departmentDescription);
  }                                                             
  // deletes a department                                       
  public function DeleteDepartment($departmentId)               
  {                                                             
     return $this->mDoCatalog->DeleteDepartment($departmentId); 
  }                                                             
  // adds a department                                          
  public function AddDepartment($departmentName, $departmentDescription)
  {                                                             
     $this->mDoCatalog->AddDepartment($departmentName, $departmentDescription);
  }                                                             
  // gets categories in a department
  public function GetCategoriesInDepartmentWithDescriptions($departmentId)
  {
    $result=$this->mDoCatalog->GetCategoriesInDepartmentWithDescriptions($departmentId);
    return $result;
  }

  // adds a category
  public function AddCategory($departmentId, $categoryName, $categoryDescription)
  {
    $this->mDoCatalog->AddCategory($departmentId, $categoryName, $categoryDescription);
  }

  // deletes a category
  public function DeleteCategory($categoryId)
  {
    return $this->mDoCatalog->DeleteCategory($categoryId);
  }

  // updates a category
  public function UpdateCategory($categoryId, $categoryName, $categoryDescription)
  {
    $this->mDoCatalog->UpdateCategory($categoryId, $categoryName, $categoryDescription);
  }

  // gets products in a category
  public function GetProductsInCategoryAdmin($categoryId)
  {
    $result=$this->mDoCatalog->GetProductsInCategoryAdmin($categoryId);
    return $result;
  }
  
  // creates a product and assigns it to a category
  public function CreateProductToCategory($categoryId, $productName,
                                            $productDescription, $productPrice,
                                            $productImage1,$productImage2,$onDepartmentPromotion,
                                            $onCatalogPromotion)
  {
    $this->mDoCatalog->CreateProductToCategory($categoryId, $productName,
                                            $productDescription, $productPrice,
                                            $productImage1,$productImage2,$onDepartmentPromotion,
                                            $onCatalogPromotion);
  }

  // updates a product
  public function UpdateProduct($productId, $productName,
                                  $productDescription, $productPrice,
                                  $productImage1,$productImage2, $onDepartmentPromotion,
                                  $onCatalogPromotion)
  {
  
    $this->mDoCatalog->UpdateProduct($productId, $productName,
                                  $productDescription, $productPrice,
                                  $productImage1,$productImage2, $onDepartmentPromotion,
                                  $onCatalogPromotion);
  }
  // removes a product from the product catalog                          
  public function DeleteProduct($productId)                              
  {                                                                      
     $this->mDoCatalog->DeleteProduct($productId);                       
  }                                                                      
  // unassigns a product from a category                                 
  public function RemoveProductFromCategory($productId, $categoryId)     
  {                                                                      
     return $this->mDoCatalog->RemoveProductFromCategory($productId,     
                                                                $categoryId);
  }                                                                      
  // retrieves the complete list of categories                           
  public function GetCategories()                                        
  {                                                                      
     return $this->mDoCatalog->GetCategories();                          
  }                                                                                      
  // retrieves the list of categories a product belongs to  
  public function GetCategoriesForProduct($productId)       
  {                                                         
     return $this->mDoCatalog->GetCategoriesForProduct($productId);
  }                                                         
  // assigns a product to a category                        
  public function AssignProductToCategory($productId, $categoryId)
  {                                                         
     $this->mDoCatalog->AssignProductToCategory($productId, $categoryId);
  }                                                         
  // moves a product from one category to another           
  public function MoveProductToCategory($productId,         
                                              $sourceCategoryId,
                                              $targetCategoryId)
  {                                                         
     return $this->mDoCatalog->MoveProductToCategory($productId,
                                                           $sourceCategoryId,
                                                           $targetCategoryId);
  }                                                         
  // changes the name of the first product image file in the database
  public function SetPicture1($productId,$pictureName)      
  {                                                         
     $this->mDoCatalog->SetPicture1($productId,$pictureName);
  }                                                         
  // changes the name of the second product image file in the database
  public function SetPicture2($productId,$pictureName)      
  {                                                         
     $this->mDoCatalog->SetPicture2($productId,$pictureName);
  }                    



       
}                                                         
//end BoCatalog                                           
?>                                             