<?php                                                            
// Reference config files and business tier                      
require_once 'include/app_top.php';                              
require_once SITE_ROOT . '/business_objects/bo_catalog.php';     
// If admin is not logged, redirect to the login page            
if (!(isset($_SESSION['AdminLogged'])) || $_SESSION['AdminLogged'] !=true)
{                                                                
  header('Location: admin_login.php?ReturnPage=catalog_admin.php');
  exit;                                                          
}                                                                
// If logging out ...                                            
if (isset($_GET['Page']) && $_GET['Page'] == "Logout")           
{                                                                
  unset($_SESSION['AdminLogged']);                               
  header("Location: index.php");                                 
  exit;                                                          
}                                                                
// Load the page                                                 
$page = new Page();                                              
$pageContent = "blank.tpl";   
// If Page is not explicitly set, assume the Departments page
if(isset($_GET['Page']))         
  $admin_page = $_GET['Page'];   
else                             
  $admin_page = "Departments";   
// Choose what admin page to load ...
if ($admin_page == "Departments") 
  $pageContent = "admin_departments.tpl";
if ($admin_page == "Categories")
  $pageContent = "admin_categories.tpl";
if ($admin_page == "Products")
  $pageContent = "admin_products.tpl";
if ($admin_page == "ProductDetails")                             
 $pageContent = "admin_product_details.tpl"; 
                          
$page->assign("pageContent", $pageContent);                      
$page->display('catalog_admin.tpl');                             
// Load app_bottom which closes the database connection          
require_once 'include/app_bottom.php';                           
?>                