<?php  
// data tier class
class DoCatalog 
{      
  // class constructor
  function __construct()
  {    
    // get the global DbManager instance (created in app_top.php)
    $this->dbManager = $GLOBALS['gDbManager'];
  }    
  // retrieves all departments
  public function GetDepartments()
  {    
    $query_string = "SELECT department_id, name FROM department";
    $result = $this->dbManager->DbGetAll($query_string);
    return $result;
  }    
  // retrieves all details for the mentioned department
  public function GetDepartmentDetails($departmentId)
  {                      
    $query_string = "SELECT name, description
                     FROM department
                     WHERE department_id = $departmentId";
    $result = $this->dbManager->DbGetRow($query_string);
    return $result;     
  }     
  // retrieves categories that belong to the mentioned department
  public function GetCategoriesInDepartment($departmentId)
  {                                                      
    $query_string = "SELECT category_id, name            
                     FROM category                     
                     WHERE department_id = $departmentId";
    $result = $this->dbManager->DbGetAll($query_string);                         
    return $result;                                      
  }    
  // retrieves details about the mentioned category      
  public function GetCategoryDetails($categoryId)        
  {                                                      
    $query_string =                                      
              "SELECT name AS category_name, description AS category_description
               FROM category                                     
               WHERE category_id = $categoryId";                 
    $result = $this->dbManager->DbGetRow($query_string); 
    return $result;                                      
  }            
  // counts how many records are returned by a SELECT command                       
  private function CountQueryRecords($queryString)                                  
  {                                                                                 
     // test if $queryString is a valid SELECT query                                
     if (strtoupper(substr($queryString, 0, 6)) != 'SELECT')                        
       trigger_error("Not a SELECT statement");                                     
     $from_position = stripos($queryString, "FROM ");                               
     if ($from_position == false)                                                   
       trigger_error("Bad SELECT statement");                                       
     // if the previous call to CountQueryRecords had the same SELECT string        
     // as parameter, we return directly the cached response                        
     if (isset($_SESSION['last_count_query']))                                      
       if ($_SESSION['last_count_query'] == $queryString)                           
         return $_SESSION['last_count'];                                            
     // calculate the number of records the SELECT query returns                    
     $count_query = "SELECT COUNT(*) ".substr($queryString, $from_position);        
     $items_count = $this->dbManager->DbGetOne($count_query);                       
     // save the query and its record count in the session                          
     $_SESSION['last_count_query'] = $queryString;                                  
     $_SESSION['last_count'] = $items_count;                                        
     // return the calculated number of records
     return $items_count;
  }            
  // alters a SQL query to return only the specified page of products
  private function CreateSubpageQuery($queryString, $pageNo, &$rTotalPages)
  {                                                      
    // calculate number of records returned by the SELECT query
    $items_count = $this->CountQueryRecords($queryString);
    // if we have few products then we don't implement pagination
    if ($items_count <= PRODUCTS_PER_PAGE)               
    {                                                    
      $pageNo = 1;                                       
      $rTotalPages = 1;                                  
    }                                                    
    // else we calculate number of pages and the new SELECT query
    else                                                 
    {                                                    
      $rTotalPages = ceil($items_count / PRODUCTS_PER_PAGE);
      $start_page = ($pageNo - 1) * PRODUCTS_PER_PAGE;   
      $queryString .= " LIMIT " . $start_page . "," . PRODUCTS_PER_PAGE;
    }                                                    
    return $queryString;                                 
  }         
  // retrieves a list of products that belong to the specified category
  public function GetProductsInCategory($categoryId, $pageNo, &$rTotalPages)
  {           
    $query_string = 
      "SELECT product.product_id, product.name,
         CONCAT(LEFT(description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."), '...')
            AS description,
         product.price, product.image_file_1,
         product.on_department_promotion, product.on_catalog_promotion
       FROM product INNER JOIN product_category
       ON product.product_id = product_category.product_id
       WHERE product_category.category_id = $categoryId";
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);
  }   
  // retrieves the products that are on promotion for the specified department
  public function GetProductsOnDepartmentPromotion($departmentId, $pageNo,
    &$rTotalPages)                                       
  {                                                      
    $query_string =                                      
        "SELECT DISTINCT product.product_id, product.name,
            CONCAT(LEFT(product.description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."),
             '...') AS description,                      
            product.price, product.image_file_1          
         FROM product                                    
         INNER JOIN product_category                     
            ON product.product_id = product_category.product_id
         INNER JOIN category                             
            ON product_category.category_id = category.category_id
         WHERE product.on_department_promotion = 1       
            AND category.department_id=$departmentId";   
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);      
  }   
  // retrieves the list of products on catalog promotion
  public function GetProductsOnCatalogPromotion($pageNo, &$rTotalPages)
  {             
    $query_string = 
      "SELECT   
         product.product_id, product.name,
            CONCAT(LEFT(description,".SHORT_PRODUCT_DESCRIPTION_LENGTH."), '...')
            AS description,
         product.price, product.image_file_1
       FROM product
       WHERE product.on_catalog_promotion = 1";
    $page_query = $this->CreateSubpageQuery($query_string, $pageNo, $rTotalPages);
    return $this->dbManager->DbGetAll($page_query);
  }             
  // retrieves complete product details
  public function GetProductDetails($productId)
  {             
    $query_string = 
      "SELECT product_id, name, description,
               price, image_file_1, image_file_2
       FROM product
       WHERE product_id = $productId";
    return $this->dbManager->DbGetRow($query_string);
  }             
  // Search product catalog                                                            
  public function Search($words, $allWords, $pageNo, &$rTotalPages)                    
  {                                                                       
     // if $allWords is "on" then we append a "+" to each word in the $words array
     if (strcmp($allWords, "on") == 0)                                    
       for ($i = 0; $i < count($words); $i++)                             
         $words[$i] = "+" . $words[$i];                                   
     // join the $words array to create a single search string            
     $temp_string = $words[0];                                            
     for ($i = 1; $i < count($words); $i++)                               
       $temp_string = $temp_string . " $words[$i]";                       
     // build search query                                                
     if (strcmp($allWords, "on") == 0)                                    
       // build all-words search query                                    
       $query_string = "SELECT product_id, name, CONCAT(LEFT(description,"
                          . SHORT_PRODUCT_DESCRIPTION_LENGTH .            
                         "),'...') AS description, price, image_file_1    
                         FROM product                                     
                         WHERE MATCH (name,description)                   
                         AGAINST (\"$temp_string\" IN BOOLEAN MODE)       
                         ORDER BY MATCH (name,description)                
                         AGAINST (\"$temp_string\" IN BOOLEAN MODE)";     
     else                                                                 
       // built any-words search query                                    
       $query_string = "SELECT product_id, name, CONCAT(LEFT(description,"
                          . SHORT_PRODUCT_DESCRIPTION_LENGTH .            
                         "),'...') AS description, price, image_file_1    
                         FROM product                                     
                         WHERE MATCH (name,description)                   
                            AGAINST (\"$temp_string\")";                  
     // call CreateSubpageQuery to implement paging                       
     $page_query = $this->CreateSubpageQuery($query_string, $pageNo,      
                                                  $rTotalPages);          
     // execute the query and return the results                          
     return $this->dbManager->DbGetAll($page_query);                      
  }                                                                 

} //end DoCatalog
?>     
