<?php                                             
// Load Smarty library and config files           
require_once 'include/app_top.php';    
 /* if not visiting a product page, save the link to the current page 
   in the PageLink session variable; it will be used to create the 
   Continue Shopping link in the product details page and the links 
   to product details pages */
if (!isset($_GET['ProductID']))
  $_SESSION['PageLink'] = "http://" . $_SERVER['SERVER_NAME'] .
  ":" . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI'];

// Load Business Tier                             
require_once SITE_ROOT . '/business_objects/bo_catalog.php';
// Load Smarty template file                      
$page = new Page();                               
$pageContentsCell = "first_page_contents.tpl";                  
$categoriesCell = "blank.tpl";                    
// load department details if visiting a department
if (isset($_GET['DepartmentID']))                 
{                                                 
  $pageContentsCell = "department.tpl";           
  $categoriesCell = "categories_list.tpl";        
}             
if (isset($_GET['Search'])) 
  $pageContentsCell="search_results.tpl";
if (isset($_GET['ProductID']))                    
  $pageContentsCell = "product.tpl";                                                           
$page->assign("pageContentsCell", $pageContentsCell);
$page->assign("categoriesCell", $categoriesCell);
$page->display('index.tpl');
// Load app_bottom which closes the database connection
require_once 'include/app_bottom.php';
?>     
