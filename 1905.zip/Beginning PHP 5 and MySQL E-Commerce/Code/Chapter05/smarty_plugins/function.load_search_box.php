<?php                                                             
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_search_box($params, $smarty)        
{                                                                 
  $search_box = new SearchBox();                                  
  // assign template variable                                     
  $smarty->assign($params['assign'], $search_box);                
}                                                                 
// class that manages the search box                              
class SearchBox                                                   
{                                                                 
  /* public variables for the smarty template */                  
  public $mSearchString = "";                                     
  public $mAllWords = "off";                                      
  /* constructor */                                               
  function __construct()                                          
  {                                                               
    $this->mBoCatalog = new BoCatalog();
    if (isset($_GET['Search']))
       $this->mSearchString = $_GET['Search'];
    if (isset($_GET['AllWords']))
       $this->mAllWords = $_GET['AllWords'];
  }     
} //end class
?>      
