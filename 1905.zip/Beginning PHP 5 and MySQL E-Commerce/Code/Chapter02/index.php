<?php                                                                                  
// load Smarty library and config files                                                
require_once 'include/app_top.php';                                                    
// Load Smarty template file                                                           
$page = new Page();                                                                    
$page->display('index.tpl');                                                           
?>                                                          