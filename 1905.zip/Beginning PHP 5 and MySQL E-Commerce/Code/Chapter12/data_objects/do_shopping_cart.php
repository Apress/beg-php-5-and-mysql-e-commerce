<?php                                                               
// data tier class for shopping cart operations                     
class DoShoppingCart                                                
{                                                                   
  // constructor                                                    
  function __construct()                                            
  {                                                                 
    // get the global DbManager instance (created in app_top.php)   
    $this->dbManager = $GLOBALS['gDbManager'];                      
  }      
  // adds a product to the shopping cart
  public function AddProduct($productId, $cartId)
  {                                 
    // first we check if $productId exists in shopping cart
    $query_string = "SELECT quantity
                   FROM shopping_cart
                   WHERE product_id = $productId AND cart_id = '$cartId'";
    // if the product doesn't exist in the shopping cart...
    if ($this->dbManager->DbGetOne($query_string) == null)
    {                               
      // add the product to the shopping cart
      $query_string = "INSERT INTO shopping_cart 
                       (cart_id, product_id, quantity, date_product_added)
                       VALUES ('$cartId', $productId , 1, now())";
    }                               
    // if the product already exists in the shopping cart...
    else                            
    {                               
      // increase product quantity by one and set the 'when_to_buy'
      // column to 'now' (in case the product was being saved for later)
           $query_string = "UPDATE shopping_cart 
                              SET quantity = quantity + 1, 
                                   when_to_buy='now'
                              WHERE product_id = $productId 
                                AND cart_id = '$cartId'";
    }                               
    $this->dbManager->DbQuery($query_string);
  }        
    // updates the shopping cart                                             
  public function Update($productId, $quantity,$cartId)                    
  {                                                                        
    // here we update the shopping cart quantities                         
    for($i=0; $i<count($productId); $i++)                                  
    {                                                                      
      if (is_numeric($quantity[$i]))                                       
         // if quantity is positive, update the quantity                   
         if($quantity[$i] > 0)                                             
            $query_string =                                                
              "UPDATE shopping_cart                                        
               SET quantity = $quantity[$i], date_product_added = now()    
               WHERE cart_id = '$cartId' AND product_id = $productId[$i]"; 
         // if the new quantity is negative or zero, remove the product    
         else                                                              
            $query_string =                                                
              "DELETE FROM shopping_cart                                   
               WHERE cart_id = '$cartId' AND product_id = $productId[$i]"; 
      $this->dbManager->DbQuery($query_string);                            
    }                                                                      
  }                        
  // removes product from the shopping cart                                
  public function RemoveProduct($productId, $cartId)                       
  {                                                                        
    $query_string = "DELETE FROM shopping_cart                             
                       WHERE product_id = $productId                       
                       AND cart_id = '$cartId'";                           
    $this->dbManager->DbQuery($query_string);                              
  }            
    // gets shopping cart products                             
  public function GetProducts($cartProductsType, $cartId)    
  {                                                          
    // if retrieving "active" shopping cart products...      
    if ($cartProductsType == GET_CART_PRODUCTS)              
    {                                                        
     $query_string =                                         
        "SELECT product.product_id, product.name,            
                 product.price, shopping_cart.quantity,      
                 product.price * shopping_cart.quantity AS subtotal
         FROM shopping_cart INNER JOIN product               
            ON shopping_cart.product_id = product.product_id 
         WHERE shopping_cart.cart_id = '$cartId'             
            AND when_to_buy='now'";                          
    }                                                        
    // if retrieving products saved for later...             
    elseif ($cartProductsType == GET_CART_SAVED_PRODUCTS)    
    {                                                        
     $query_string =                                         
        "SELECT product.product_id, product.name, product.price
         FROM shopping_cart INNER JOIN product               
            ON shopping_cart.product_id = product.product_id 
         WHERE shopping_cart.cart_id = '$cartId'             
            AND when_to_buy='later'";                        
    }                                                        
    else                                                     
      trigger_error("$cartProductsType value unknown", E_USER_ERROR);
    return $this->dbManager->DbGetAll($query_string);        
  }          
    // gets total amount of the shopping cart products                       
  public function GetTotalAmount($cartId)                                  
  {                                                                        
    $query_string =                                                        
       "SELECT SUM(product.price * shopping_cart.quantity) AS total_amount 
        FROM shopping_cart INNER JOIN product                              
           ON shopping_cart.product_id = product.product_id                
        WHERE shopping_cart.cart_id = '$cartId'";                          
    $result = $this->dbManager->DbGetOne($query_string);                   
    return $result;                                                        
  }            
    // moves a shopping cart product to the "save for later" list            
  public function SaveProductToBuyLater($productId, $cartId)               
  {                                                                        
    $query_string = "UPDATE shopping_cart                                  
                       SET when_to_buy = 'later', quantity = 1             
                       WHERE product_id = $productId                       
                         AND cart_id = '$cartId'";                         
    $result = $this->dbManager->DbQuery($query_string);                    
  }           
    // moves a product from the "save for later" list to the shopping cart   
  public function MoveProductToCart($productId, $cartId)                   
  {                                                                        
    $query_string = "UPDATE shopping_cart                                  
                       SET when_to_buy='now'                               
                       WHERE product_id = $productId                       
                         AND cart_id = '$cartId'";                         
    $result = $this->dbManager->DbQuery($query_string);                    
  }          
    // deletes old shopping carts                          
  public function DeleteOldShoppingCarts($days)          
  {                                                      
    // query that gets the card_ids for old carts        
    $query_string =                                      
       "SELECT cart_id, date_product_added               
        FROM shopping_cart                               
        GROUP BY cart_id                                 
        HAVING DATE_SUB(CURDATE(), INTERVAL $days DAY)   
                >= MAX(date_product_added)";             
    $result = $this->dbManager->DbGetAll($query_string); 
    // removes all items from the old carts              
    for ($i=0; $i<count($result); $i++)                  
    {                                                    
       $query_string="DELETE FROM shopping_cart          
                        WHERE cart_id='{$result[$i]['cart_id']}'";
       $this->dbManager->DbQuery($query_string);         
    }                                                    
    return count($result);                               
  }                       
    // empties visitor's shopping cart                            
  public function EmptyShoppingCart($cartId)                    
  {                                                             
    $query_string = "DELETE FROM shopping_cart                  
                       WHERE cart_id='$cartId'";                
    $this->dbManager->DbQuery($query_string);                   
  }        
  // creates a new order                                                                
  public function CreateOrder($cartId, $customerId)                                     
  {                                                                                     
     // insert the new order                                                            
     $query_string =                                                                    
       "INSERT INTO orders                                                              
             (date_created, status, customer_id)                                        
        VALUES                                                                          
             (NOW(), 0, $customerId)";                                                  
     $this->dbManager->DbQuery($query_string);                                          
     // gets the id of the inserted order                                               
     $query_string="SELECT LAST_INSERT_ID()";                                           
     $order_id = $this->dbManager->DbGetOne($query_string);                             
     // get order's items                                                               
     $query_string =                                                                    
       "SELECT product.product_id, product.name,       
                shopping_cart.quantity, product.price  
        FROM product JOIN shopping_cart                
          ON product.product_id = shopping_cart.product_id
        WHERE shopping_cart.cart_id = '$cartId'";      
     $order_items = $this->dbManager->DbGetAll($query_string);  
     // Insert order items in order_detail table and calculate total amount
     $total_amount=0;                                  
     for ($i=0; $i<count($order_items); $i++)          
     {                                                 
       $total_amount += $order_items[$i]['price'];     
       $query_string =                                 
         "INSERT INTO order_detail                     
               (order_id, product_id, product_name, quantity, unit_cost)
          VALUES                                       
               ($order_id, {$order_items[$i]['product_id']}, 
                '" . $order_items[$i]['name'] . "',    
                {$order_items[$i]['quantity']},        
                {$order_items[$i]['price']})";         
       $this->dbManager->DbQuery($query_string);       
     }                                                 
     // set order's total amount                       
     $query_string =                                   
       "UPDATE orders                                  
        SET total_amount = $total_amount               
        WHERE customer_id = $customerId AND order_id = $order_id";
     $this->dbManager->DbQuery($query_string);         
     //delete shopping cart                            
     $this->EmptyShoppingCart($cartId);                
     return $order_id;                                 
  }                                           
}                                                                   
?>     