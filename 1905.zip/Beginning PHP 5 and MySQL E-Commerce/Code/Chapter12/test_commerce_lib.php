<?php                                          
require_once 'include/config.inc.php';         
require_once SITE_ROOT . '/include/app_top.php';
require_once COMMERCELIB_DIR . 'commerce_lib.all.php';
require_once SITE_ROOT . '/business_objects/bo_customer.php';
require_once SITE_ROOT . '/business_objects/bo_order_manager.php';
$order_id = 1;                                
$customer_id = 1;                              
$bo_customer = new BoCustomer();               
$order_manager = new BoOrderManager();         
$customer_data = $bo_customer->GetCustomer($customer_id);
try                                            
{                                              
  $customer = new Customer($customer_data);    
}                                              
catch(Exception $e)                            
{                                              
  echo'Exception: ' . $e->getMessage();        
  exit;                                        
}                                              
echo "Customer found. Address:<br/>";          
echo "<pre>";                                  
echo $customer->mAddressAsString;              
echo "</pre>";                                 
echo "Customer credit card number: " .         
      $customer->mCreditCard->GetCardNumberX() . "<br/>";
$order_command = $order_manager->GetOrderDetails($order_id);
try                                            
{                                              
  $order_object = new OrderDetails($order_command);
}                                              
catch(Exception $e)                            
{                                              
  Echo 'Exception :' . $e->getMessage() ;      
  exit;                                        
}                                              
echo "<br/>Order found. Details:<br/>";        
echo "<pre>";                                  
echo $order_object->mListAsString;             
echo "</pre>";                                 
echo "<br/>";                                  
echo "List of items names:<br/>";              
for ($i = 0; $i < count($order_object->mList); $i++)
  echo $order_object->mList[$i]->mProductName."<br/>";
?>                                             

