<?php        
// SITE_ROOT contains the full path to the tshirtshop folder
define("SITE_ROOT", dirname(dirname(__FILE__)));
// Settings needed to configure the Smarty template engine
define("SMARTY_DIR", SITE_ROOT."/libs/smarty/");
define("TEMPLATE_DIR", SITE_ROOT."/templates");
define("COMPILE_DIR", SITE_ROOT."/templates_c");
define("CONFIG_DIR", SITE_ROOT."/configs");
// these should be true while developing the web site        
define("IS_WARNING_FATAL", true);                            
define("DEBUGGING", true);                                   
// settings about mailing the error messages to admin        
define("SEND_ERROR_MAIL", false);                            
define("ADMIN_ERROR_MAIL", "admin_mail@localhost");          
define("SENDMAIL_FROM", "errors@tshirtshop.com");            
ini_set("sendmail_from", SENDMAIL_FROM);                     
// by default we don't log errors to a file                  
define("LOG_ERRORS", false);                                 
define("LOG_ERRORS_FILE", "c:\\tshirtshop\\errors_log.txt"); // Windows
// define("LOG_ERRORS_FILE", "/var/tmp/tshirtshop_errors.log"); // Unix
// Generic error message to be diplayed instead of debug info
// (when DEBUGGING is false)                                 
define("SITE_GENERIC_ERROR_MESSAGE", "<h2>TShirtShop Error!</h2>");
if ((substr(strtoupper(PHP_OS), 0, 3)) == "WIN") 
  define("PATH_SEPARATOR", ";");
else      
  define("PATH_SEPARATOR", ":");
ini_set('include_path', SITE_ROOT . '/libs/PEAR' . 
         PATH_SEPARATOR . ini_get('include_path'));
// database login info
define("USE_PERSISTENT_CONNECTIONS", "true");
define("DB_SERVER", "localhost");
define("DB_USERNAME", "admin");
define("DB_PASSWORD", "admin");
define("DB_DATABASE", "tshirtshop");
define("MYSQL_CONNECTION_STRING", "mysql://" . DB_USERNAME . ":" . 
        DB_PASSWORD . "@" . DB_SERVER . "/" . DB_DATABASE);
// Configure product display options
define("SHORT_PRODUCT_DESCRIPTION_LENGTH",130);
define("PRODUCTS_PER_PAGE",4);
// minimum word length for searches; this constant must be kept in sync
// with the ft_min_word_len MySQL variable                        
define("FT_MIN_WORD_LEN",4); 
define("ADMIN_USERNAME", "admin");                                            
define("ADMIN_PASSWORD", "admin"); 
// shopping cart item types                                         
define("GET_CART_PRODUCTS",1);                                      
define("GET_CART_SAVED_PRODUCTS",2); 
// cart actions                                                     
define("ADD_PRODUCT",1);                                            
define("REMOVE_PRODUCT",2);                                         
define("UPDATE_PRODUCTS_QUANTITIES",3);                             
define("SAVE_PRODUCT_FOR_LATER",4);                                 
define("MOVE_PRODUCT_TO_CART",5);  
// random value used for hashing                                                               
define("HASH_PREFIX", "K1-");   
// constant definitions for commerce lib classes
define("COMMERCELIB_DIR", SITE_ROOT . "/business_objects/commerce_lib/");
define("NEWLINE", "\n");
// constant definitions for order handling related messages
define("ADMIN_EMAIL","misu@cristiandarie.ro");
$admin_email_params=array('host' => 'cristiandarie.ro', 
                          'auth' => true,
                          'username' => 'misu@cristiandarie.ro',
                          'password' => 'misu200'); 
define("CUSTOMER_SERVICE_EMAIL","misu@cristiandarie.ro");
$customer_service_email_params = array('host' => 'cristiandarie.ro', 
                                       'auth' => true,
                                       'username' => 'misu@cristiandarie.ro',
                                       'password' => 'misu200'); 
define("ORDER_PROCESSOR_EMAIL","misu@cristiandarie.ro");
$order_processor_email_params = array('host' => 'cristiandarie.ro', 
                               'auth' => true,
                               'username' => 'misu@cristiandarie.ro',
                               'password' => 'misu200'); 
define("SUPPLIER_EMAIL","misu@cristiandarie.ro");
          
?>