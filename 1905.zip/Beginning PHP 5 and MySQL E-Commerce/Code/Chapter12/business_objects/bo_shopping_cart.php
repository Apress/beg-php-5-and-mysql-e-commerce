<?php   
// reference data tier class for shopping cart management
require_once SITE_ROOT . '/data_objects/do_shopping_cart.php';
// business tier class for the shopping cart
class BoShoppingCart
{       
  // instance of the data tier shopping cart class
  private $mDoShoppingCart;
  // stores the visitor's Cart ID
  private static $mCartId;
  // constructor
  public function __construct()
  {     
    // initialize data tier object
    $this->mDoShoppingCart = new DoShoppingCart();
    // ensure we have a cart id for the current visitor in the session
    $this->SetCartId();
  }     
  // called at the beginning of index.php to ensure we have the
  // visitor's cart ID in the visitor's session
  public static function SetCartId()
  {     
    // if the cart ID hasn't already been set...
    if (self::$mCartId == "")
    {   
       // if the visitor's cart ID is in the session, get it from there
       if (isset($_SESSION['cartId']))
       {                                                            
         self::$mCartId = $_SESSION['cartId'];                      
       }                                                            
       // if not, check if the cart ID was saved as a cookie        
       elseif (isset($_COOKIE['cartId']))                           
       {                                                            
         // save the cart ID from the cookie                        
         self::$mCartId = $_COOKIE['cartId'];                       
         $_SESSION['cartId'] = self::$mCartId;                      
       }                                                            
       else                                                         
       {                                                            
         // generate cart id and save it to the $mCartId class member, 
         // the session and a cookie (on subsequent requests mCartId 
         // will be populated from the session)                     
         self::$mCartId = md5(uniqid(rand(), true));                
         // store cart id in session                                
         $_SESSION['cartId'] = self::$mCartId;                      
         // cookie will be valid for 7 days                         
         setcookie('cartId', self::$mCartId, time() + 432000);      
       }                                                            
    }                                                               
  }                                                                 
  // returns the current visitor's card id                          
  public function GetCartId()                                       
  {                                                                 
    return self::$mCartId;                                          
  }                                                                 
  // adds product to the shopping cart                              
  public function AddProduct($productId)                            
  {                                                                 
    $this->mDoShoppingCart->AddProduct($productId, $this->GetCartId());
  }                                                                 
  // updated the shopping cart with new product quantities          
  // ($productId and $quantity are arrays that contain product ids  
  //  and their respective quantities)                              
  public function Update($productId, $quantity)                     
  {                                                                 
    $this->mDoShoppingCart->Update($productId, $quantity,           
                                        $this->GetCartId());        
  }                                                                 
  // removes product from shopping cart                             
  public function RemoveProduct($productId)                         
  {                                                       
    $this->mDoShoppingCart->RemoveProduct($productId,     
                                                $this->GetCartId());
  }                                                       
  // save product to the "save for later" list            
  public function SaveProductToBuyLater($productId)       
  {                                                       
    $this->mDoShoppingCart->SaveProductToBuyLater($productId, 
                                                         $this->GetCartId());
  }                                                       
  // get product from the "save for later" list back to the cart
  public function MoveProductToCart($productId)           
  {                                                       
    $this->mDoShoppingCart->MoveProductToCart($productId, 
                                                    $this->GetCartId());
  }                                                       
  // get shopping cart products                           
  public function GetCartProducts($cartProductsType)      
  {                                                       
    return $this->mDoShoppingCart->GetProducts($cartProductsType, 
                                                     $this->GetCartId ());
  }                                                       
  // gets total amount of shopping cart products          
  // (not including the ones that are being saved for later)
  public function GetTotalAmount()                        
  {                                                       
    return $this->mDoShoppingCart->GetTotalAmount($this->GetCartId());
  }      
     // deletes old shopping carts                          
  public function DeleteOldShoppingCarts($days)          
  {                                                      
    return $this->mDoShoppingCart->DeleteOldShoppingCarts($days,
                                                        $this->GetCartId());
  }               
   // create a new order from the shopping cart        
   public function CreateOrder()                       
   {                                                   
     $bo_customer = new BoCustomer();                  
     $customer_id = $bo_customer->GetCurrentCustomerId();
     return $this->mDoShoppingCart->CreateOrder($this->GetCartId(), $customer_id);
  }                                      
}                                                         
?>    