<?php                            
// reference the Mail PEAR library
require_once 'Mail.php';         
// Main class, used to obtain order information,
// run pipeline sections, audit orders, etc.
class OrderProcessor             
{                                
  public $mOrderId;              
  public $mOrderStatus;          
  public $mConnection;           
  public $mConfiguration;        
  public $mContinueNow;          
  private $mCurrentCustomer;     
  private $mCurrentOrderDetails; 
  private $mOrderManager;        
  private $mReference;           
  private $mAuthCode;            
  // constructor creates DoOrderManager instance
  function __construct()         
  {                              
    $this->mOrderManager = new DoOrderManager();
  }                              
  // Process is called from checkout.php and orders_admin.php to process an 
  // order; the first parameter is the ID of the order, and the second 
  // parameter is an OrderProcessorConfiguration instance. 
  public function Process($newOrderId, $newConfiguration)
  {                                            
    // set order ID                            
    $this->mOrderId = $newOrderId;             
    // configure processor                     
    $this->mConfiguration = $newConfiguration; 
    $this->mContinueNow = true;                
    // log start of execution                  
    $this->AddAudit("Order Processor started.", 10000);
    // obtain status of order                  
    $this->mOrderStatus = $this->mOrderManager->GetOrderStatus($this->mOrderId);
    // process pipeline section                
    try                                        
    {                                          
       while ($this->mContinueNow)             
       {                                       
         $this->mContinueNow = false;          
         $cps = $this->GetCurrentPipelineSection();
         $cps->Process($this);                 
       }                                       
    }                                          
    catch(Exception $e)                        
    {                                          
       trigger_error('Exception "' . $e->getMessage() . '" on ' . 
                       $e->getFile() . " line " . $e->getLine());
       $this->MailAdmin("Order Processing error ocured.", $e->getMessage());
       $this->AddAudit("Order Processing error ocured.", 10002);
       throw new Exception("processor error"); 
    }                                          
    $this->AddAudit("Order Processor finished.", 10001);
  }                                            
  // gets current pipeline section             
  private function GetCurrentPipelineSection() 
  {                                            
    return new PsDummy();                      
  }                                            
  // sends email                               
  public function Mail($params, $to, $headers, $message)
  {                                            
    // Create the mail object using the Mail::factory method
    $mail_object = Mail::factory('smtp', $params);
    // Test the mail object is valid           
    if (PEAR::isError($mail_object))           
       throw new Exception($mail_object->getMessage());
    // sends email                             
    $result = $mail_object->send($to, $headers, $message);
    // Test if mail was sent successfully      
    if (PEAR::isError($result))  
       throw new Exception("Unable to send e-mail to $to. " .
                             $result->getMessage());
  }                              
  // builds email message        
  public function MailAdmin($subject, $message)
  {                              
    // usually you are not allowed to set the 'From' header
    $headers['From'] = $this->mConfiguration->mOrderProcessorEmail;
    $headers['Subject'] = $subject;
    $headers['To'] = $this->mConfiguration->mAdminEmail;
    $this->Mail($this->mConfiguration->mOrderProcessorEmailParams, 
                  $this->mConfiguration->mAdminEmail, 
                  $headers,      
                  $message);     
  }                              
  // gets the customer that made the order
  public function GetCurrentCustomer()
  {                              
    if (empty($this->mCurrentCustomer))
    {                            
       $this->mCurrentCustomer = new 
        Customer($this->mOrderManager->GetCustomerByOrderId($this->mOrderId));
       if (empty($this->mCurrentCustomer))
         throw new Exception($this->mOrderId . " order doesn't have a
customer");                      
    }                            
    return $this->mCurrentCustomer;
  }                              
  // gets the details of the current order
  public function GetCurrentOrderDetails()
  {                              
    if (empty($this->mCurrentOrderDetails))
    {                            
       $this->mCurrentOrderDetails = new 
         OrderDetails($this->mOrderManager->GetOrderDetails($this->mOrderId));
       if (empty($this->mCurrentOrderDetails))
         throw new Exception($this->mOrderId . 
                                " doesn't have order details entry");
    }                            
    return $this->mCurrentOrderDetails;
  }                              
  // adds audit message          
  public function AddAudit($message, $messageNumber)
  {                              
    $this->mOrderManager->AddAudit($this->mOrderId, $message, $messageNumber);
  }                              
  // updates order status                      
  public function UpdateOrderStatus($newStatus)
  {                                            
    $this->mOrderManager->UpdateOrderStatus($this->mOrderId, $newStatus);
    $this->mOrderStatus = $newStatus;          
  }           
    // set order's authorization code and reference code           
  public function SetOrderAuthCodeAndReference($newAuthCode, $newReference)
  {                                                              
    $this->mOrderManager->SetOrderAuthCodeAndReference($this->mOrderId, 
                                                              $newAuthCode, 
                                                              $newReference);
    $this->mAuthCode = $newAuthCode;                             
    $this->mReference = $newReference;                           
  }     
                   
  // gets order authorization code and reference code            
  private function GetOrderAuthCodeAndReference()                
   {                                                              
     $result = $this->mOrderManager->GetOrderAuthCodeAndReference(
                                                                 $this->mOrderId);
     if (empty($result)) throw Exception($this->mOrderId." doesn't exist");
     $this->mAuthCode = $result['auth_code'];                     
     $this->mReference = $result['reference'];                    
   }                                                              
   // gets order authorization code                               
  public function GetAuthCode()
  {                      
     if (empty($this->mAuthCode)) $this->GetOrderAuthCodeAndReference();
     return $this->mAuthCode; 
  }                      
  // gets order reference code
  public function GetReference()
  {                      
     if (empty($this->mReference)) $this->GetOrderAuthCodeAndReference();
     return $this->mReference; 
  }     
    // set order's ship date
  public function SetDateShipped()
  {                     
    $this->mOrderManager->SetDateShipped($this->mOrderId);
  }                          
}                    
                          
?>     