<?php                                          
class PsDummy implements IPipelineSection      
{                                              
  public function Process($processor)          
  {                                            
    $processor->AddAudit("PsDoNothing started.",99999);
    $processor->AddAudit("Customer: " .        
                            $processor->GetCurrentCustomer()->mName, 99999);
    $processor->AddAudit("First item in order: " . 
    $processor->GetCurrentOrderDetails()->mList[0]->mItemAsString, 99999);
    $processor->MailAdmin("Test.", "Test mail from PsDummy.", 99999);
    $processor->AddAudit("PsDoNothing finished", 99999);
  }                                            
}                                              
?>      