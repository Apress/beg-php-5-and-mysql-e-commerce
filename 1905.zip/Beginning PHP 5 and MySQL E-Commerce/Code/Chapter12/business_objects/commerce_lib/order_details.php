<?php                            
// represents array of order detail objects 
class OrderDetails               
{                                
  public $mList; // array of OrderDetail objects
  public $mTotalCost;            
  public $mListAsString = "";    
  // retrieves a number of records and stores them as OrderDetail instances
  function __construct($orderDetails)
  {                              
    // simple test to guard against void input data
    if (empty($orderDetails))    
       throw new Exception("Empty Order Details");
    // populates the mList array 
    for ($i = 0; $i < count($orderDetails); $i++)
    {                            
       // creates a new OrderDetail instance
       $new_order_detail = new OrderDetail($orderDetails[$i]['product_id'],
         $orderDetails[$i]['product_name'], $orderDetails[$i]['quantity'],
         $orderDetails[$i]['unit_cost']);
       // saves the new OrderDetail instance into the mList array
       $this->mList[$i] = $new_order_detail;
       // builds output string   
       $this->mListAsString .= $new_order_detail->mItemAsString . NEWLINE;
       // adds product cost to total cost
       $this->mTotalCost += $new_order_detail->mCost;
    }                            
    // finishes building the output string
    $this->mListAsString .= NEWLINE . "Total order cost: $" . 
                                $this->mTotalCost;
  }                              
}                                
?>                               

