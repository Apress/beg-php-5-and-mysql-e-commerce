<?php   
// represents a customer
class Customer 
{       
  public $mCustomerId;
  public $mName;
  public $mEmail;
  public $mCreditCard;
  public $mAddress1;
  public $mAddress2;
  public $mCity;
  public $mRegion;
  public $mPostalCode;
  public $mCountry;
  public $mPhone;
  public $mAddressAsString;
  // constructor receives customer data from the database as parameter
  function __construct($customer)              
  {                                            
    // simple test to check we didn't receive void parameter
    if (empty($customer)) throw new Exception("No customer data");
    // save customer data in class members     
    $this->mCustomerId = $customer['customer_id'];
    $this->mName = $customer['name'];          
    $this->mEmail = $customer['email'];        
    $this->mAddress1 = $customer['address1'];  
    $this->mAddress2 = $customer['address2'];  
    $this->mCity = $customer['city'];          
    $this->mRegion = $customer['region'];      
    $this->mPostalCode = $customer['postal_code'];
    $this->mCountry = $customer['country'];    
    $this->mPhone = $customer['phone'];        
    // decrypt credit card data                
    $this->mCreditCard = new SecureCard();     
   $this->mCreditCard->LoadEncryptedDataAndDecrypt($customer['credit_card']);
    $this->mSddressAsString = $this->mName . NEWLINE . 
                                  $this->mAddress1 . NEWLINE; 
    if (!(empty($this->mAddress2)))            
       $this->mAddressAsString .= $this->mAddress2 . NEWLINE;
    $this->mAddressAsString .= $this->mCity . NEWLINE . 
                                   $this->mRegion . NEWLINE . 
                                   $this->mPostalCode . NEWLINE . 
                                   $this->mCountry . NEWLINE;
  }                                            
}                                              
?>  