<?php                                          
// an instance of this class represents an ordered product 
class OrderDetail                              
{                                              
  public $mProductId;                          
  public $mProductName;                        
  public $mQuantity;                           
  public $mUnitCost;                           
  public $mItemAsString;                       
  public $mCost;                               
  // constructor receives item's details and saves them to class members
  function __construct($newProductId, $newProductName, 
                          $newQuantity, $newUnitCost)
  {                                            
    $this->mProductId = $newProductId;
    $this->mProductName = $newProductName;
    $this->mQuantity = $newQuantity;
    $this->mUnitCost = $newUnitCost;
    $this->mCost = $this->mUnitCost * $this->mQuantity;
    $this->mItemAsString = $this->mQuantity . " " . 
                               $this->mProductName . " $" . 
                               $this->mUnitCost . " each, total cost $" . 
                               $this->mCost . NEWLINE;
   }                             
}                                
?>    