<?php                                        
// reference configuration files             
require_once 'include/config.inc.php';       
require_once SITE_ROOT . '/include/app_top.php';
require_once COMMERCELIB_DIR . 'commerce_lib.all.php';
// sets an order id                            
$order_id = 3;                                
//                                             
$configuration = new OrderProcessorConfiguration
    (ADMIN_EMAIL,                              
      $GLOBALS['admin_email_params'],          
      CUSTOMER_SERVICE_EMAIL,                  
      $GLOBALS['customer_service_email_params'],
      ORDER_PROCESSOR_EMAIL,                   
      $GLOBALS['order_processor_email_params'],
      SUPPLIER_EMAIL);                         
$processor = new OrderProcessor();             
try                                            
{                                              
  $processor->Process($order_id, $configuration);
}                                              
catch (Exception $e)                           
{                                              
  echo $e->getMessage() . ' on ' . $e->getFile() . " line " . $e->getLine();
  exit;                                        
}                                              
echo "Finished";                               
?>  