<?php  
// data tier class
class DoCatalog 
{      
  // class constructor
  function __construct()
  {    
    // get the global DbManager instance (created in app_top.php)
    $this->dbManager = $GLOBALS['gDbManager'];
  }    
  // retrieves all departments
  public function GetDepartments()
  {    
    $query_string = "SELECT department_id, name FROM department";
    $result = $this->dbManager->DbGetAll($query_string);
    return $result;
  }    
} //end DoCatalog
?>     
