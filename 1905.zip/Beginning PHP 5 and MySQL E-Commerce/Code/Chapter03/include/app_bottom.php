<?php                                                        
$GLOBALS['gDbManager']->DbDisconnect();                      
?>         