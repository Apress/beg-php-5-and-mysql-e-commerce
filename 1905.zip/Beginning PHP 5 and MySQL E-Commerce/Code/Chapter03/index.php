<?php                                                                                  
// load Smarty library and config files                                                
require_once 'include/app_top.php';    
// Load Business Tier                             
require_once SITE_ROOT.'/business_objects/bo_catalog.php';                                                
// Load Smarty template file                                                           
$page = new Page();                                                                    
$page->display('index.tpl');        
// Load app_bottom which closes the database connection      
require_once 'include/app_bottom.php';                                                                         
?>                                                          