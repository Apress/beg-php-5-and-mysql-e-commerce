<?php                                             
// reference the data tier                        
require_once SITE_ROOT.'/data_objects/do_catalog.php';
// business tier class for reading product catalog information
class BoCatalog                                   
{                                                 
  /* private stuff */                             
  private $mDoCatalog;                            
  // class constructor initializes the data tier object
  function __construct()
  {    
    $this->mDoCatalog = new DoCatalog();
  }    
  // retrieves all departments
  public function GetDepartments()
  {    
    $result = $this->mDoCatalog->GetDepartments();
    return $result;
  }    
} //end BoCatalog
?>     
