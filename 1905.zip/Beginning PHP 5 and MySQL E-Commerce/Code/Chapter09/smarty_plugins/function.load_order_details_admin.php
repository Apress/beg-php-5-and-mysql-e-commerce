<?php                                                    
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_order_details_admin($params, $smarty)
{                                                        
  $order_details_admin = new OrderDetailsAdmin();        
  $order_details_admin->init();                          
  // assign template variable                            
  $smarty->assign($params['assign'], $order_details_admin);
}                                                        
// presentation tier class that deals with administering order details
class OrderDetailsAdmin                                  
{                                                        
  /* public variables available in smarty template */    
  public $mOrderId;                                      
  public $mOrderInfo;                                    
  public $mOrderDetails;                                 
  public $mEditButtonEnabled;                            
  public $mUpdateButtonEnabled;                          
  public $mCancelButtonEnabled;                          
  public $mDateCreatedTextBoxEnabled;                    
  public $mVerifiedTextBoxEnabled;                       
  public $mCompletedTextBoxEnabled;                      
  public $mCanceledTextBoxEnabled;                       
  public $mCommentsTextBoxEnabled;                       
  public $mCustomerNameTextBoxEnabled;                   
  public $mShippingAddressTextBoxEnabled;                
  public $mCustomerEmailTextBoxEnabled;                  
  public $mMarkAsVerifiedButtonEnabled;                  
  public $mMarkAsCompletedButtonEnabled;                 
  public $mMarkAsCanceledButtonEnabled;
  /* private attributes */
  private $mOrderManager;
  // class constructor
  function __construct()
  {       
    // we receive the order ID in the query string
    if (isset($_GET['OrderId'])) 
      $this->mOrderId = (int) $_GET['OrderId'];
    else  
      trigger_error("OrderId paramater is required");
    // initialize instance of business tier class
    $this->mOrderManager = new BoOrderManager;
  }       
  // initializes class members
  function init()
  {       
    if (isset($_GET['markAsVerifiedButton']))
       $this->mOrderManager->MarkOrderAsVerified($this->mOrderId);
    if (isset($_GET['markAsCompletedButton']))
       $this->mOrderManager->MarkOrderAsCompleted($this->mOrderId);
    if (isset($_GET['markAsCanceledButton']))
       $this->mOrderManager->MarkOrderAsCanceled($this->mOrderId);
    if (isset($_GET['updateButton']))
    {     
       $this->mOrderManager->UpdateOrder(
         $this->mOrderId,
         $_GET['dateCreatedTextBox'], 
         $_GET['dateShippedTextBox'],
         isset($_GET['verifiedCheckBox']) ? "on" : "off",  
         isset($_GET['completedCheckBox']) ? "on" : "off",
         isset($_GET['canceledCheckBox']) ? "on" : "off", 
         $_GET['commentsTextBox'],
         $_GET['customerNameTextBox'], 
         $_GET['shippingAddressTextBox'],
         $_GET['customerEmailTextBox']);
    }     
    $this->PopulatePage();
    if (isset($_GET['editButton']))
       $this->SetEditMode(true);
    else  
       $this->SetEditMode(false);
  }       
  // fills the order details form with data
  public function PopulatePage()
  {                                                      
    $this->mOrderInfo = $this->mOrderManager->GetOrderInfo($this->mOrderId);
    $this->mEditButtonEnabled = true;                    
    $this->mUpdateButtonEnabled = false;                 
    $this->mCancelButtonEnabled = false;                 
    if (($this->mOrderInfo['canceled'] == 1)             
      || ($this->mOrderInfo['completed'] == 1))          
    {                                                    
       $this->mMarkAsVerifiedButtonEnabled = false;      
       $this->mMarkAsCompletedButtonEnabled = false;     
       $this->mMarkAsCanceledButtonEnabled = false;      
    }                                                    
    elseif ($this->mOrderInfo['verified'] == 1)          
    {                                                    
       $this->mMarkAsVerifiedButtonEnabled = false;      
       $this->mMarkAsCompletedButtonEnabled = true;      
       $this->mMarkAsCanceledButtonEnabled = true;       
    }                                                    
    else                                                 
    {                                                    
       $this->mMarkAsVerifiedButtonEnabled = true;       
       $this->mMarkAsCompletedButtonEnabled = false;     
       $this->mMarkAsCanceledButtonEnabled = true;       
    }                                                    
    $this->mOrderDetails =                               
            $this->mOrderManager->GetOrderDetails($this->mOrderId);
  }                                                      
  // input value is boolean value which specifies whether to 
  // enable or disable edit mode                         
  public function SetEditMode($value)                    
  {                                                      
    $this->mDateCreatedTextBoxEnabled = $value;          
    $this->mDateShippedTextBoxEnabled = $value;          
    $this->mVerifiedTextBoxEnabled = $value;             
    $this->mCompletedTextBoxEnabled = $value;            
    $this->mCanceledTextBoxEnabled = $value;             
    $this->mCommentsTextBoxEnabled = $value;             
    $this->mCustomerNameTextBoxEnabled = $value;         
    $this->mShippingAddressTextBoxEnabled = $value;      
    $this->mCustomerEmailTextBoxEnabled = $value;        
    $this->mEditButtonEnabled = !$value;                 
    $this->mUpdateButtonEnabled = $value;                
    $this->mCancelButtonEnabled = $value;                
  }                                                      
} //end class                                            
?>     