<?php                                                    
// plugin functions inside plugin files must be named: smarty_type_name
function smarty_function_load_orders_list_admin($params, $smarty)
{                                                        
  $orders_list_admin = new OrdersListAdmin();            
  $orders_list_admin->init();                            
  // assign template variable                            
  $smarty->assign($params['assign'], $orders_list_admin);
}                                                        
// presentation tier class that supports order administration functionality
class OrdersListAdmin                                    
{                                                        
  /* public variables available in smarty template */    
  public $mOrders;                                       
  public $mStartDate;                                    
  public $mEndDate;                                      
  public $mRecordCount = 20;                             
  public $mErrorLabel = "";                              
  /* private attributes */                               
  private $mOrderManager;                                 
  // constructor                                          
  function __construct()                                  
  {                                                       
    $this->mOrderManager = new BoOrderManager();          
  }                                                       
  // init                                                 
  function init()                                         
  {                                                       
    // if the "most recent x orders" filter is in action...
    if (isset($_GET['mostRecentButton']))                 
    {                                                     
       // if the record count value is not a valid integer, display error
       if ((string)(int)$_GET['recordCountTextBox'] ==    
           (string)$_GET['recordCountTextBox'])           
       {                                                  
         $this->mRecordCount = (int) $_GET['recordCountTextBox'];
         $this->mOrders = $this->mOrderManager->GetMostRecentOrders(
                                                         $this->mRecordCount);
       }                                                  
       else                                               
         $this->mErrorLabel = $_GET['recordCountTextBox'] . 
                                 " is not a number. <br />";
    }                                                     
    // if the "orders between d1 and d2" filter is in action...
    if (isset($_GET['betweenDatesButton']))               
    {                                                     
       $this->mStartDate = $_GET['startDateTextBox'];     
       $this->mEndDate = $_GET['endDateTextBox'];         
       // check if the start date is in accepted format   
       if (($this->mStartDate == "") ||                   
           ($timestamp = strtotime($this->mStartDate)) == -1)
         $this->mErrorLabel = "The start date is invalid. <br />";
       else                                               
         // transform date to YYYY/MM/DD HH:MM:SS format  
         $this->mStartDate =                              
              strftime("%Y/%m/%d %H:%M:%S", strtotime($this->mStartDate));
       // check if the end date is in accepted format     
       if (($this->mEndDate == "") ||                     
           ($timestamp = strtotime($this->mEndDate)) == -1)
         $this->mErrorLabel .= "The end date is invalid. <br />";
       else                                               
         // transform date to YYYY/MM/DD HH:MM:SS format  
         $this->mEndDate =                                
              strftime("%Y/%m/%d %H:%M:%S", strtotime($this->mEndDate));
       // check if start date is more recent than the end date
       if ((empty($this->mErrorLabel)) &&                
           (strtotime($this->mStartDate) > strtotime($this->mEndDate)))
         $this->mErrorLabel .=                           
           "The start date should be more recent than the end date.";
       // if there are no errors, get the orders between the two dates
       if (empty($this->mErrorLabel))                    
         $this->mOrders = $this->mOrderManager->GetOrdersBetweenDates(
                                        $this->mStartDate, $this->mEndDate);
    }                                                    
    // if "unverified orders" filter is in action...     
    if (isset($_GET['unverifiedOrdersButton']))          
       $this->mOrders =                                  
               $this->mOrderManager->GetUnverifiedUncanceledOrders();
    // if "verified orders" filter is in action...       
    if (isset($_GET['verifiedOrdersButton']))            
       $this->mOrders =                                  
               $this->mOrderManager->GetVerifiedUncompletedOrders();
  }                                                      
} //end class                                            
?>             