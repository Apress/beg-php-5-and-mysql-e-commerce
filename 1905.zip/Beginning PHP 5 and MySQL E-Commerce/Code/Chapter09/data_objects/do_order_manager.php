<?php          
// data tier class that supports order administration functionality
class DoOrderManager
{              
   private $dbManager;
   // class constructor
   function __construct()
   {           
     // get the global DbManager instance (created in app_top.php)
     $this->dbManager = $GLOBALS['gDbManager'];
   }    
   // get the most recent $count orders
   public function GetMostRecentOrders($count)
   {           
     $query_string =                                             
       "SELECT order_id, total_amount, date_created, date_shipped, 
                verified, completed, canceled, customer_name     
        FROM orders                                              
        ORDER BY date_created DESC                               
        LIMIT $count";                                           
     $result = $this->dbManager->DbGetAll($query_string);        
     return $result;                                             
  }    
    // get orders between two dates                                
  public function GetOrdersBetweenDates($startDate, $endDate)    
  {                                                              
     $query_string =                                             
       "SELECT order_id, total_amount, date_created, date_shipped, 
                verified, completed, canceled, customer_name     
        FROM orders                                              
        WHERE date_created >= '$startDate' AND date_created <='$endDate'
        ORDER BY date_created DESC";                             
     $result = $this->dbManager->DbGetAll($query_string);        
     return $result;                                             
  }      
    // gets pending orders that need to be either verified or canceled
  public function GetUnverifiedUncanceledOrders()                
  {                                                              
     $query_string =                                             
       "SELECT order_id, total_amount, date_created, date_shipped, 
                verified, completed, canceled, customer_name     
        FROM orders                                              
        WHERE verified=0 AND canceled=0                          
        ORDER BY date_created DESC";                             
     $result=$this->dbManager->DbGetAll($query_string);          
     return $result;                                             
  }    
    // gets pending orders that need to be shipped
  public function GetVerifiedUncompletedOrders()
  {              
     $query_string = 
       "SELECT order_id, total_amount, date_created, date_shipped, 
                verified, completed, canceled, customer_name
        FROM orders 
        WHERE verified=1 AND completed=0
        ORDER BY date_created DESC";   
     $result = $this->dbManager->DbGetAll($query_string);
     return $result; 
  }       
  // gets the details of a specific order
  public function GetOrderInfo($orderId)
  {                                  
     $query_string =                 
       "SELECT order_id, total_amount, date_created, date_shipped, 
                verified, completed, canceled, comments,
                customer_name, shipping_address, customer_email
        FROM orders                  
        WHERE order_id = $orderId";  
        $result = $this->dbManager->DbGetRow($query_string);
     return $result;                 
  }       
    // gets the products that belong to a specific order
  public function GetOrderDetails($orderId)
  {                                  
     $query_string =                 
       "SELECT orders.order_id, product_id, product_name, quantity, 
                unit_cost, quantity*unit_cost AS subtotal               
        FROM order_detail JOIN orders
        ON orders.order_id = order_detail.order_id
        WHERE orders.order_id = $orderId"; 
     $result = $this->dbManager->DbGetAll($query_string);
     return $result;                 
  }       
   // updates order details           
  public function UpdateOrder ($orderId, $dateCreated, $dateShipped, 
                                    $verified, $completed, $canceled, 
                                    $comments, $customerName, 
                                    $shippingAddress, $customerEmail)
  {                                  
     $query_string =                                             
       "UPDATE orders                                            
        SET date_created = '$dateCreated',                       
            date_shipped = '$dateShipped',                       
            verified = $verified,                                
            completed = $completed,                              
            canceled = $canceled,                                
            comments = '$comments',                              
            customer_name = '$customerName',                     
            shipping_address = '$shippingAddress',               
            customer_email = '$customerEmail'                    
        WHERE order_id = $orderId";                              
     $result = $this->dbManager->DbQuery($query_string);         
     return $result;                                             
  }       
    // sets the verified bit of an order to 1                     
  public function MarkOrderAsVerified($orderId)                 
  {                                                             
    $query_string = "UPDATE orders                              
                       SET verified = 1                         
                       WHERE order_id = $orderId";              
    $result = $this->dbManager->DbQuery($query_string);         
    return $result;                                             
  }  
    // sets the completed bit of an order to 1 and populates shipped_date
  public function MarkOrderAsCompleted($orderId)                
  {                                                             
    $query_string = "UPDATE orders                              
                       SET completed = 1, date_shipped = NOW()  
                       WHERE order_id = $orderId";              
    $result = $this->dbManager->DbQuery($query_string);         
    return $result;                                             
  }            
    // sets the canceled bit of an order to 1
  public function MarkOrderAsCanceled($orderId)
  {                               
    $query_string="UPDATE orders  
                     SET canceled = 1
                     WHERE order_id = $orderId";
    $result = $this->dbManager->DbQuery($query_string);
    return $result;               
  }                                                        

                 
}              
?>       