<?php            
// reference data tier class
require_once SITE_ROOT . '/data_objects/do_order_manager.php';
// business tier class that supports order administration functionality
class BoOrderManager 
{                
   // private attributes
   private $mDoOrderManager; 
   // class constructor
   function __construct()
   {             
     $this->mDoOrderManager = new DoOrderManager();  
   }             
   // get the most recent $count orders
   public function GetMostRecentOrders($count)
   {             
     $result = $this->mDoOrderManager->GetMostRecentOrders($count);
     return $result; 
   }             
   // get orders between two dates
   public function GetOrdersBetweenDates($startDate, $endDate)
   {             
     $result =   
      $this->mDoOrderManager->GetOrdersBetweenDates($startDate,$endDate);
     return $result;                                             
  }                                                              
  // gets pending orders that need to be either verified or canceled
  public function GetUnverifiedUncanceledOrders()                
  {                                                              
     $result = $this->mDoOrderManager->GetUnverifiedUncanceledOrders();
     return $result;                                             
  }                                                              
  // gets pending orders that need to be shipped                 
  public function GetVerifiedUncompletedOrders()                 
  {                                                              
     $result = $this->mDoOrderManager->GetVerifiedUncompletedOrders();
     return $result;                                             
  }                     
    // gets the details of a specific order
  public function GetOrderInfo($orderId)
  {                               
    $result = $this->mDoOrderManager->GetOrderInfo($orderId);
    return $result;               
  }                               
  // gets the products that belong to a specific order
  public function GetOrderDetails($orderId)
  {                               
    $result = $this->mDoOrderManager->GetOrderDetails($orderId);
    return $result;               
  }                               
  // updates order details        
  public function UpdateOrder($orderId, $dateCreated, $dateShipped, 
                                 $verified, $completed, $canceled, 
                                 $comments, $customerName,
                                 $shippingAddress, $customerEmail)
  {                               
    $result = $this->mDoOrderManager->UpdateOrder ($orderId, 
         $dateCreated, $dateShipped, $verified=="on"?1:0,
         $completed=="on"?1:0, $canceled=="on"?1:0, $comments,
         $customerName, $shippingAddress, $customerEmail);
    return $result;               
  }                               
  // marks an order as verified   
  public function MarkOrderAsVerified($orderId)
  {                               
    $result = $this->mDoOrderManager->MarkOrderAsVerified($orderId);
    return $result;               
  }                                                              
  // marks an order as completed and sets the order's ship_date  
  public function MarkOrderAsCompleted($orderId)                 
  {                                                              
     $result = $this->mDoOrderManager->MarkOrderAsCompleted($orderId);
     return $result;                                             
  }                                                              
  // marks an order as canceled                                  
  public function MarkOrderAsCanceled($orderId)                  
  {                                                              
     $result = $this->mDoOrderManager->MarkOrderAsCanceled($orderId);
     return $result;                                             
  }                                                   
}//end class                                                     
?>       