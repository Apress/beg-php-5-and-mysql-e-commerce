<?php          
// data tier class that supports order administration functionality
class DoOrderManager
{              
   private $dbManager;
   // class constructor
   function __construct()
   {           
     // get the global DbManager instance (created in app_top.php)
     $this->dbManager = $GLOBALS['gDbManager'];
   }             
  // gets the products that belong to a specific order
  public function GetOrderDetails($orderId)
  {                                  
     $query_string =                 
       "SELECT orders.order_id, product_id, product_name, quantity, 
                unit_cost, quantity*unit_cost AS subtotal               
        FROM order_detail JOIN orders
        ON orders.order_id = order_detail.order_id
        WHERE orders.order_id = $orderId"; 
     $result = $this->dbManager->DbGetAll($query_string);
     return $result;                 
  }       
  
  // gets status of an order                   
  public function GetOrderStatus($orderId)     
  {                                            
    $query_string = "SELECT status FROM orders WHERE order_id=$orderId";
    $result = $this->dbManager->DbGetOne($query_string);
    return $result;                            
  }                                            
  // adds audit record                         
  public function AddAudit($orderId, $message, $messageNumber)
  {                                            
    $query_string = "INSERT INTO audit (order_id, datestamp, 
                                             message, message_number)
                        VALUES ($orderId, NOW(), '$message', $messageNumber)";
    $result = $this->dbManager->DbQuery($query_string); 
    return $result;              
  }                              
  // gets the data of a customer that made a particular order
  public function GetCustomerByOrderId($orderId)
  {                              
    $query_string = "SELECT customer.customer_id, customer.name, 
                                customer.email, customer.password,
                                customer.credit_card, customer.address1,
                                customer.address2, customer.city,
                                customer.region, customer.postal_code, 
                                customer.country, customer.phone
                        FROM customer INNER JOIN orders
                          ON customer.customer_id = orders.customer_id
                        WHERE orders.order_id = $orderId"; 
    $result=$this->dbManager->DbGetRow($query_string); 
    return $result;              
  }    
    // updates the order pipeline status of an order
  public function UpdateOrderStatus($orderId, $status)
  {                      
     $query_string = "UPDATE orders SET status=$status WHERE order_id=$orderId";
     $result = $this->dbManager->DbQuery($query_string); 
     return $result;     
  }          
    // sets order's authorization code
  public function SetOrderAuthCodeAndReference($orderId, $authCode, $reference)
  {                      
     $query_string = "UPDATE orders 
                        SET auth_code='$authCode', reference='$reference'
                        WHERE order_id=$orderId";
     $result=$this->dbManager->DbQuery($query_string); 
     return $result;     
  }        
    // set order's ship date
  public function SetDateShipped($orderId)
  {                     
    $query_string = "UPDATE orders 
                       SET date_shipped=NOW() 
                       WHERE order_id=$orderId";
    $result = $this->dbManager->DbQuery($query_string); 
    return $result;     
  }                 
  // gets order's authorization code                             
  public function GetOrderAuthCodeAndReference($orderId)         
  {                                                              
    $query_string = "SELECT auth_code, reference                 
                       FROM orders                               
                       WHERE order_id=$orderId";                 
    $result = $this->dbManager->DbGetRow($query_string);         
    return $result;                                              
  }     
  // retrieves all data from the status table                   
  public function GetStatuses()                                 
  {                                                             
     $query_string = "SELECT status_id, description FROM status";
     $result = $this->dbManager->DbGetAll($query_string);       
     return $result;                                            
  }                                                             
  // gets the  details of a specific order                                   
  public function GetOrder($orderId)                            
  {                                                             
     $query_string =                                            
       "SELECT orders.order_id, orders.date_created, orders.date_shipped, 
                orders.status, orders.customer_id, orders.auth_code,
                orders.reference, status.description, customer.name
        FROM orders INNER JOIN customer                         
          ON customer.customer_id = orders.customer_id          
        INNER JOIN status                                       
          ON status.status_id = orders.status                   
        WHERE orders.order_id = $orderId";
    $result = $this->dbManager->DbGetRow($query_string); 
    return $result;
  }               
  // gets all orders          
  public function GetOrders()
  {               
    $query_string = 
       "SELECT orders.order_id, orders.date_created, orders.date_shipped, 
                orders.status, orders.customer_id, status.description, customer.name
        FROM orders INNER JOIN customer
          ON customer.customer_id = orders.customer_id
        INNER JOIN status
          ON status.status_id = orders.status";
    $result = $this->dbManager->DbGetAll($query_string); 
    return $result;
  }               
  // gets specified number of most recent orders
  public function GetOrdersByRecent($count)
  {               
    $query_string = 
       "SELECT orders.order_id, orders.date_created, orders.date_shipped,
                orders.status, orders.customer_id, status.description, customer.name
        FROM orders INNER JOIN customer
          ON customer.customer_id = orders.customer_id
        INNER JOIN status
          ON status.status_id = orders.status
        ORDER BY date_created DESC LIMIT $count";
    $result = $this->dbManager->DbGetAll($query_string); 
    return $result;
  }               
  // gets all orders placed by a specified customer
  public function GetOrdersByCustomer($customerId)
  {               
    $query_string = 
       "SELECT orders.order_id, orders.date_created, orders.date_shipped,  
                orders.status, orders.customer_id, status.description, customer.name
        FROM orders INNER JOIN customer
          ON customer.customer_id = orders.customer_id
        INNER JOIN status
          ON status.status_id = orders.status
        WHERE orders.customer_id = $customerId";
    $result = $this->dbManager->DbGetAll($query_string); 
    return $result;
  }               
  // gets orders between two specified dates
  public function GetOrdersByDate($startDate, $endDate)         
  {                                                             
    $query_string =                                             
       "SELECT orders.order_id, orders.date_created, orders.date_shipped, 
                orders.status, orders.customer_id, status.description, customer.name
        FROM orders INNER JOIN customer                         
          ON customer.customer_id = orders.customer_id          
        INNER JOIN status                                       
          ON status.status_id = orders.status                   
        WHERE orders.date_created > '$startDate'                
          AND orders.date_created < '$endDate'";                
    $result = $this->dbManager->DbGetAll($query_string);        
    return $result;                                             
  }                                                             
  // gets all orders with a specific status                     
  public function GetOrdersByStatus($status)                    
  {                                                             
    $query_string =                                             
       "SELECT orders.order_id, orders.date_created, orders.date_shipped, 
                orders.status, orders.customer_id, status.description, customer.name
                        FROM orders INNER JOIN customer         
                        ON customer.customer_id = orders.customer_id
                        INNER JOIN status                       
                        ON status.status_id = orders.status     
                        WHERE orders.status = $status";         
    $result=$this->dbManager->DbGetAll($query_string);          
    return $result;                                             
  }                                                             
  // gets the audit table entries associated with a specific order
  public function GetGetAuditTrail($orderId)                    
  {                                                             
    $query_string = "SELECT datestamp, message_number, message  
                        FROM audit                              
                        WHERE order_id = $orderId";             
    $result = $this->dbManager->DbGetAll($query_string);        
    return $result;                                             
  }                 
}              
?>       