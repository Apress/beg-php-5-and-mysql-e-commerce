<?php                                                 
require_once 'include/config.inc.php';                
require_once SITE_ROOT . '/include/app_top.php';      
require_once COMMERCELIB_DIR . 'commerce_lib.all.php';
// change this to reflect one of your orders          
$order_id = 3;                                        
// initial step is 1                                  
if (isset($_GET['step']))                             
  $step = (int)$_GET['step'];                         
else                                                  
  $step=0;                                            
$step++;                                              
// if the Execute! button was clicked...              
if ($step!=1)                                         
{                                                     
  // step == 2 -> 1st call to OrderProcessor, normally from checkout.php
  // step == 3 -> 2nd call to OrderProcessor, normally from orders_admin_page.php                                 
  // step == 4 -> 3rd call to OrderProcessor, normally from orders_admin_page.php                                 
  $configuration = new OrderProcessorConfiguration(   
                                ADMIN_EMAIL,          
                                $GLOBALS['admin_email_params'],
                                CUSTOMER_SERVICE_EMAIL,
                                $GLOBALS['customer_service_email_params'],
                                ORDER_PROCESSOR_EMAIL,
                                $GLOBALS['order_processor_email_params'],
                                SUPPLIER_EMAIL);      
  // creates new OrderProcessor instance and uses it 
  $processor = new OrderProcessor();
  try   
  {     
    $processor->Process($order_id, $configuration);
  }     
  catch (Exception $e) 
  {     
    echo $e->getMessage();
    exit;
  }     
}       
if ($step==4) 
{       
 echo "Finished.";
 exit;  
}       
?>      
<form action="test_processor.php">
<input type="hidden" name="step" value="<?php echo $step; ?>">
Execution number <?php echo $step; ?> of Process() method 
<input type=submit value="Execute!">
</form> 
