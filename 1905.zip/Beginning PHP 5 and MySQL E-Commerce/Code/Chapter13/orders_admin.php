<?php       
// load config files
require_once 'include/app_top.php';
// load business objects
require_once COMMERCELIB_DIR . 'commerce_lib.all.php';
require_once 'business_objects/bo_order_manager.php';
// if admin is not logged in, redirect to admin_login.php page
if (!isset($_SESSION['AdminLogged']) || $_SESSION['AdminLogged'] != true)
{           
  header('Location: admin_login.php?ReturnPage=orders_admin.php');
  exit;     
}           
// if logging out ...
if (isset($_GET['logout']))
{           
  unset($_SESSION['AdminLogged']);
  header("Location:index.php");
  exit;     
}           
// load Smarty template ...
$page = new Page();
$orderDetailsCell = "blank.tpl";
if (isset($_GET['OrderId']))
  $orderDetailsCell = "order_details_admin.tpl";
$page->assign("orderDetailsCell", $orderDetailsCell);
$page->display('orders_admin.tpl');
?>  