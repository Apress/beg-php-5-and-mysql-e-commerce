<?php                                                         
class PsShipGoods implements IPipelineSection                 
{                                                             
  private $mProcessor;                                        
  private $mCurrentCustomer;                                  
  private $mCurrentOrderDetails;                              
  public function Process($processor)                         
  {                                                           
     $this->mProcessor = $processor;                          
     $processor->AddAudit("PSShipGoods started.", 20500);     
     $this->mCurrentCustomer = $processor->GetCurrentCustomer();
     $this->mCurrentOrderDetails = $processor->GetCurrentOrderDetails();
     $headers['From'] = $processor->mConfiguration->mAdminEmail;
     $headers['To'] = $processor->mConfiguration->mSupplierEmail;
     $headers['Subject'] = "Ship goods.";                     
     $processor->Mail($processor->mConfiguration->mAdminEmailParams, 
                        $processor->mConfiguration->mSupplierEmail, 
                        $headers,                             
                        $this->GetMailBody());                
     $processor->AddAudit("Ship goods email sent to supplier.", 20502);
     $processor->UpdateOrderStatus(6);                        
     $processor->AddAudit("PSShipGoods finished.", 20501);    
  }                                                           
  private function GetMailBody()                              
  {                                                           
     $body = "Payment has been received for the following goods:";
     $body.= NEWLINE;                                         
     $body.= NEWLINE;                                         
     $body.= $this->mCurrentOrderDetails->mListAsString;      
     $body.= NEWLINE;                                         
     $body.= NEWLINE;                                         
     $body.= "Please ship to:";                               
     $body.= NEWLINE;
     $body.= NEWLINE;
     $body.= $this->mCurrentCustomer->mAddressAsString;
     $body.= NEWLINE;
     $body.= NEWLINE;
     $body.= "When goods have been shipped, please confirm via " . 
              "http://www.tshirtshop.com/orders_admin_page.php";
     $body.= NEWLINE;
     $body.= NEWLINE;
     $body.= "Order reference number: ";
     $body.= $this->mProcessor->mOrderId;
     return $body;
  }             
}               
?>   