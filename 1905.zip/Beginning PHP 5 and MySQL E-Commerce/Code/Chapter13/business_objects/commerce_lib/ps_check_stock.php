<?php           
class PsCheckStock implements IPipelineSection
{               
  private $mProcessor;
  private $mCurrentOrderDetails;
  public function Process($processor)
  {             
     $this->mProcessor = $processor;
     $processor->AddAudit("PSCheckStock started.", 20200);
     $this->mCurrentOrderDetails = $processor->GetCurrentOrderDetails();
     $headers['From'] = $processor->mConfiguration->mAdminEmail;
     $headers['To'] = $processor->mConfiguration->mSupplierEmail;
     $headers['Subject'] = "Stock check.";                    
     $processor->Mail($processor->mConfiguration->mAdminEmailParams,
                        $processor->mConfiguration->mSupplierEmail,
                        $headers,                             
                        $this->GetMailBody());      
     $processor->AddAudit("Notification email sent to supplier.", 20202);
     $processor->UpdateOrderStatus(3);                        
     $processor->AddAudit("PSCheckStock finished.", 20201);   
  }    
    private function GetMailBody()                              
  {                                                           
     $body = "The following goods have been ordered:";        
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= $this->mCurrentOrderDetails->mListAsString;     
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= "Please check availability and confirm via " .  
               "http://www.tshirtshop.com/orders_admin_page.php";
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= "Order reference number: ";                     
     $body .= $this->mProcessor->mOrderId;                    
     return $body;                                            
  }                                                           
} //end class                                                 
?>        