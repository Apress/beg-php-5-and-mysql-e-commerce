<?php           
class PsCheckFunds implements IPipelineSection
{               
  private $mProcessor;
  public function Process($processor)
  {             
     $this->mProcessor = $processor;
     $processor->AddAudit("PSCheckFunds started.", 20100);     
     $processor->SetOrderAuthCodeAndReference("DummyAuthCode", "DummyReference");     
     $processor->AddAudit("Funds available for purchase.", 20102);
     $processor->UpdateOrderStatus(2);
     $processor->mContinueNow = true;
     $processor->AddAudit("PSCheckFunds finished.", 20101);
  }             
} //end class   
?>   