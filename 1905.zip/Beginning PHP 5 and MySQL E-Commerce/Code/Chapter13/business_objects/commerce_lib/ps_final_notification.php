<?php                                                         
class PsFinalNotification implements IPipelineSection         
{                                                             
  private $mProcessor;                                        
  private $mCurrentCustomer;                                  
  private $mCurrentOrderDetails;                              
  public function Process($processor)                         
  {                                                           
     $this->mProcessor = $processor;                          
     $processor->AddAudit("PSFinalNotification started.", 20700);
     $this->mCurrentCustomer = $processor->GetCurrentCustomer();
     $this->mCurrentOrderDetails = $processor->GetCurrentOrderDetails();
     $headers['From'] = $processor->mConfiguration->mCustomerServiceEmail;
     $headers['To'] = $this->mCurrentCustomer->mEmail;        
     $headers['Subject'] = "Order dispatched.";               
     $processor->Mail($processor->mConfiguration->mCustomerServiceEmailParams,
                        $this->mCurrentCustomer->mEmail,      
                        $headers,                             
                        $this->GetMailBody());                
     $processor->AddAudit("Dispatch email send to customer.", 20702);
     $processor->UpdateOrderStatus(8);                        
     $processor->AddAudit("PSFinalNotification finished.", 20701);
  }                                                           
  private function GetMailBody()                              
  {                                                           
     $body = "Your order has now been dispatched! " .         
              "The following products have been shipped:";    
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= $this->mCurrentOrderDetails->mListAsString;     
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= "Your order has been shipped to : ";            
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= $this->mCurrentCustomer->mAddressAsString;      
     $body .= NEWLINE;                                        
     $body .= NEWLINE;                                        
     $body .= "Order reference number: ";                     
     $body .= $this->mProcessor->mOrderId;                    
     $body .= NEWLINE;
     $body .= NEWLINE;
     $body .= "Thank you for shopping at TshirtShop.com!";
     return $body;
  }               
}                 
?>        