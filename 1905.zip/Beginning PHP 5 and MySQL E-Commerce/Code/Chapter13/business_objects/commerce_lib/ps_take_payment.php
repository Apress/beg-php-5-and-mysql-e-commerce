<?php                         
class PsTakePayment implements IPipelineSection
{                             
  private $mProcessor;        
  private $mAuthCode;         
  private $mReference;        
  public function Process($processor)
  {                           
     $this->mProcessor = $processor;
     $processor->AddAudit("PSTakePayment started.", 20400);
     $this->mAuthCode = $processor->GetAuthCode();
     $this->mReference = $processor->GetReference();
     $processor->AddAudit("Funds deducted from customer credit card account.",
                             20402);
     $processor->UpdateOrderStatus(5);
     $processor->mContinueNow = true;
     $processor->AddAudit("PSTakePayment finished.", 20401);
  }                                                           
}                                                             
?>      