<?php                         
class PsStockOK implements IPipelineSection
{                             
   private $mProcessor;       
   public function Process($processor)
   {                          
     $this->mProcessor = $processor;
     $processor->AddAudit("PSStockOk started.", 20300);
     $processor->AddAudit("Stock confirmed by supplier.", 20302);
     $processor->UpdateOrderStatus(4);
     $processor->mContinueNow = true;
     $processor->AddAudit("PSStockOK finished.", 20301);
   }                          
}                             
?>            