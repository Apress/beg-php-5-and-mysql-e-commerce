<?php                    
class PsInitialNotification implements IPipelineSection
{                        
  private $mProcessor;   
  private $mCurrentCustomer;
  private $mCurrentOrderDetails;
  public function Process($processor)
  {                      
     $this->mProcessor = $processor;
     $processor->AddAudit("PsInitialNotification started.", 20000);
     $this->mCurrentCustomer = $processor->GetCurrentCustomer();
     $this->mCurrentOrderDetails = $processor->GetCurrentOrderDetails();
     $headers['From'] = $processor->mConfiguration->mCustomerServiceEmail;
     $headers['To'] = $this->mCurrentCustomer->mEmail;
     $headers['Subject'] = "Order received.";
     $processor->Mail($processor->mConfiguration->mCustomerServiceEmailParams,
                        $this->mCurrentCustomer->mEmail, 
                        $headers, 
                        $this->GetMailBody());
     $processor->AddAudit("Notification email sent to customer.", 20002);
     $processor->UpdateOrderStatus(1);                        
     $processor->mContinueNow = true;                              
     $processor->AddAudit("PsInitialNotification finished.", 20001);
  }          
  private function GetMailBody()                             
  {                                                          
    $body = "Thank you for your order! " .                   
             "The products you have ordered are as follows:";
    $body.= NEWLINE;                                         
    $body.= NEWLINE;                                         
    $body.= $this->mCurrentOrderDetails->mListAsString;      
    $body.= NEWLINE;                                         
    $body.= NEWLINE;                                         
    $body.= "Your order will be shipped to:";                
    $body.= NEWLINE;                                         
    $body.= NEWLINE;                                         
    $body.= $this->mCurrentCustomer->mAddressAsString;       
    $body.= NEWLINE;                                         
    $body.= NEWLINE;                                         
    $body.= "Order reference number: ";                      
    $body.= $this->mProcessor->mOrderId;                     
    $body.= NEWLINE;                                         
    $body.= NEWLINE;                                         
    $body.= "You will receive a confirmation email when this order has been " .
             "dispatched. Thank you for shopping at TShirtShop.com!";
    return $body;                                            
  }                                                          
}                                                             
?>            