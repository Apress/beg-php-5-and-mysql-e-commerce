<?php           
class PsShipOk implements IPipelineSection
{               
   private $mProcessor;
   public function Process($processor)
   {            
     $this->mProcessor = $processor;
     $processor->AddAudit("PSShipOk started.", 20600);
     $processor->SetDateShipped();
     $processor->AddAudit("Order dispatched by supplier.", 20602);
     $processor->UpdateOrderStatus(7);
     $processor->mContinueNow = true;
     $processor->AddAudit("PSShipOK finished.", 20601);
   }            
}               
?>           