<?php   
require_once SITE_ROOT . '/business_objects/secure_card.php';
require_once SITE_ROOT . '/data_objects/do_order_manager.php';
require_once COMMERCELIB_DIR . 'customer.php';
require_once COMMERCELIB_DIR . 'order_detail.php';
require_once COMMERCELIB_DIR . 'order_details.php';
require_once COMMERCELIB_DIR . 'i_pipeline_section.php';
require_once COMMERCELIB_DIR . 'ps_dummy.php';
require_once COMMERCELIB_DIR . 'order_processor_configuration.php';
require_once COMMERCELIB_DIR . 'order_processor.php';
require_once COMMERCELIB_DIR . 'ps_initial_notification.php';
require_once COMMERCELIB_DIR . 'ps_check_funds.php';
require_once COMMERCELIB_DIR . 'ps_check_stock.php';
require_once COMMERCELIB_DIR . 'ps_stock_ok.php';
require_once COMMERCELIB_DIR . 'ps_take_payment.php';
require_once COMMERCELIB_DIR . 'ps_ship_goods.php';
require_once COMMERCELIB_DIR . 'ps_ship_ok.php';
require_once COMMERCELIB_DIR . 'ps_final_notification.php';
?>   