<?php           
// reference data tier class
require_once SITE_ROOT . '/data_objects/do_order_manager.php';
// business tier class that supports order administration functionality
class BoOrderManager 
{               
  // private attributes
  private $mDoOrderManager; 
  // class constructor
  function __construct()
  {             
     $this->mDoOrderManager = new DoOrderManager();  
  }             
  // gets order details for the order details admin page
  public function GetOrderDetails($orderId)
  {             
     $result = $this->mDoOrderManager->GetOrderDetails($orderId);
     return $result;
  }             
  // gets the customer that made a particular order
  public function GetCustomerByOrderId($orderId)
  {             
     $result = $this->mDoOrderManager->GetCustomerByOrderId($orderId);
     return $result; 
  }             
  // retrieves all possible order statuses
  public function GetStatuses()
  {             
     $result = $this->mDoOrderManager->GetStatuses();
     return $result; 
  }             
  // gets the details of a specific order
  public function GetOrder($orderId)
  {             
     $result = $this->mDoOrderManager->GetOrder($orderId);
     return $result; 
  }             
  // gets all orders
  public function GetOrders()
  {             
     $result = $this->mDoOrderManager->GetOrders();
     return $result; 
  }             
  // gets specified number of most recent orders
  public function GetOrdersByRecent($count)

  {                                                           
     $result = $this->mDoOrderManager->GetOrdersByRecent($count);
     return $result;                                          
  }                                                           
  // gets all orders placed by a specified customer           
  public function GetOrdersByCustomer($customerId)            
  {                                                           
     $result = $this->mDoOrderManager->GetOrdersByCustomer($customerId);
     return $result;                                          
  }                                                           
  // gets orders between two specified dates                  
  public function GetOrdersByDate($startDate, $endDate)       
  {                                                           
     $result = $this->mDoOrderManager->GetOrdersByDate($startDate, $endDate);
     return $result;                                          
  }                                                           
  // gets all orders with a specific status                   
  public function GetOrdersByStatus($status)                  
  {                                                           
     $result = $this->mDoOrderManager->GetOrdersByStatus($status);
     return $result;                                          
  }                                                           
  // gets the audit table entries associated with a specific order
  public function GetAuditTrail($orderId)                     
  {                                                           
     $result = $this->mDoOrderManager->GetGetAuditTrail($orderId);
     return $result;                                          
  }                                                           
}//end class                                                  
?>        