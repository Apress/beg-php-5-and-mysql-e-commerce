<?php
// ensures that checkout.php is only accessible via SSL connection                             
if ( !isset($_SERVER['HTTPS']) || strtolower($_SERVER['HTTPS']) != 'on' )                      
{                                                                                              
   header ('Location: https://'.$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI']);                                      
   exit();                                                                                     
}           
require_once 'include/config.inc.php';
require_once SITE_ROOT.'/include/app_top.php';  
require_once SITE_ROOT . '/business_objects/bo_shopping_cart.php';
require_once SITE_ROOT . '/business_objects/bo_customer.php';
require_once COMMERCELIB_DIR.'commerce_lib.all.php';
$page = new Page();
$checkout_body="checkout_info.tpl";
if (isset($_GET['AddOrChangeCreditCard'])) 
        $checkout_body="customer_credit_card.tpl";
if (isset($_GET['AddOrChangeAddress'])) 
        $checkout_body="customer_address.tpl";
$bo_customer=new BoCustomer();
if ($bo_customer->IsAuthenticated()) 
  {
   $customerLoginOrLogged="customer_logged.tpl";
   if ((isset($_GET['RegisterCustomer'])) || (isset($_GET['ChangeDetails']))) $checkout_body="customer_details.tpl";
  } 
 else {   
        $customerLoginOrLogged="customer_login.tpl";
	if ((isset($_GET['RegisterCustomer'])) || (isset($_GET['ChangeDetails']))) $checkout_body="customer_details.tpl";
           else $checkout_body="checkout_not_logged.tpl";
      }
if (isset($_GET['OrderDone'])) 
        $checkout_body="order_done.tpl";
if (isset($_GET['OrderError'])) 
        $checkout_body="order_error.tpl";
if (isset($_GET['OrderDone']))                        
  $checkout_body = "order_done.tpl";                  
if (isset($_GET['OrderError']))                       
  $checkout_body = "order_error.tpl";            
$page->assign("checkout_body",$checkout_body);
$page->assign("customerLoginOrLogged",$customerLoginOrLogged);
$page->display('checkout.tpl');
require_once 'include/app_bottom.php';
?>
