<?php                                                                                                  
// data tier class that supports customer details functionality                                        
class DoCustomer                                                                                       
{                                                                                                      
   // contains the global instance of the DbManager class                                              
   private $dbManager;                                                                                 
   // class constructor                                                                                
   function __construct()                                                                              
   {                                                                                                   
     // get the global DbManager instance (created in app_top.php)                                     
     $this->dbManager = $GLOBALS['gDbManager'];                                                        
   }   
     // returns customer_id and password for customer with email $email
  public function GetCustomerIdPassword($email)
  {                              
     $query_string="SELECT customer_id,password
                      FROM customer
                      WHERE email= '$email'";
     $result = $this->dbManager->DbGetRow($query_string);
     return $result;             
  }                
    // create a new customer and get his or her ID
  public function AddCustomer($name,$email,$password,$phone)
  {                             
    $query_string = "INSERT INTO customer (name,email,password,phone)
                       VALUES ('$name','$email','$password','$phone')";
    $this->dbManager->DbQuery($query_string);
    $query_string = "SELECT LAST_INSERT_ID()";
    $result = $this->dbManager->DbGetOne($query_string);
    return $result;             
  }            
  // get customer details       
  public function GetCustomer($customerId)
  {                              
     $query_string = "SELECT customer_id, name, password, email, 
                                credit_card, address1, address2,
                                city, region, postal_code, country, phone
                        FROM customer
                        WHERE customer_id = $customerId";
     $result = $this->dbManager->DbGetRow($query_string);
     return$result;              
  }         
  // update customer account details                                                                  
  public function UpdateCustomerDetails($customerId, $name,                                           
                                              $email, $password, $phone)                               
  {                                                                                                    
     $query_string = "UPDATE customer                                                                  
                        SET name = '$name', email = '$email',                                          
                             password='$password', phone='$phone'                                      
                        WHERE customer_id = $customerId";                                              
     $result = $this->dbManager->DbQuery($query_string);                                               
     return $result;                                                                                   
  }                          
  public function UpdateAddress($customerId, $address1, $address2,                                     
                                     $city, $region, $postalCode, $country)                            
  {                                                                                                    
     $query_string = "UPDATE customer                                                                  
                        SET address1='$address1', address2='$address2',                                
                             city='$city', region='$region',                                           
                             postal_code='$postalCode', country='$country'                             
                        WHERE customer_id=$customerId";                                                
      $result = $this->dbManager->DbQuery($query_string);                                              
      return$result;                                                                                   
  }       
  // update credit_card column for a customer                                                         
  public function UpdateCreditCard($customerId,$creditCard)                                           
  {                                                                                                   
    $query_string = "UPDATE customer                                                                  
                       SET credit_card='$creditCard'                                                  
                       WHERE customer_id=$customerId";                                                
    $result=$this->dbManager->DbQuery($query_string);                                                 
    return $result;                                                                                   
  }                   
                                                                              
} //end class                                                                                          
?>          