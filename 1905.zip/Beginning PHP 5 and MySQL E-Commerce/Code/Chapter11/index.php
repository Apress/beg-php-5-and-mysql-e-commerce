<?php             
// is the page being accessed through an HTTPS connection?
if ( !isset($_SERVER['HTTPS']) || strtolower($_SERVER['HTTPS']) != 'on' ) 
  $is_https = false;
else         
  $is_https = true;
// visiting a sensitive page?
if (isset($_GET['RegisterCustomer']) || 
    isset($_GET['ChangeDetails']) || 
    isset($_GET['AddOrChangeAddress']) || 
    isset($_GET['AddOrChangeCreditCard']) || 
    isset($_POST['Login']))
  $is_sensitive_page = true;
else         
  $is_sensitive_page = false;
// use HTTPS when accessing sensitive pages
if ($is_sensitive_page && $is_https==false)
 {           
   header ('Location: https://' . $_SERVER['HTTP_HOST'] . 
            $_SERVER['REQUEST_URI']);
   exit();   
 }           
// don't use HTTPS for nonsensitive pages
if (!$is_sensitive_page && $is_https == true)  
 {           
   header ('Location: http://' . $_SERVER['HTTP_HOST'] . 
            $_SERVER['REQUEST_URI']);
   exit();   
 }           
                                
// Load Smarty library and config files           
require_once 'include/app_top.php';    
require_once SITE_ROOT . '/business_objects/bo_shopping_cart.php';
require_once SITE_ROOT . '/business_objects/bo_customer.php';
 /* if not visiting a product page, save the link to the current page 
   in the PageLink session variable; it will be used to create the 
   Continue Shopping link in the product details page and the links 
   to product details pages */
if (!isset($_GET['ProductID']) && !isset($_GET['CartAction'])) 
  $_SESSION['PageLink'] = "http://" . $_SERVER['SERVER_NAME'] .
  ":" . $_SERVER['SERVER_PORT'] . $_SERVER['REQUEST_URI'];

// Load Business Tier                             
require_once SITE_ROOT . '/business_objects/bo_catalog.php';
// Load Smarty template file                      
$page = new Page();                               
$pageContentsCell = "first_page_contents.tpl";                  
$categoriesCell = "blank.tpl";                    
// load department details if visiting a department
if (isset($_GET['DepartmentID']))                 
{                                                 
  $pageContentsCell = "department.tpl";           
  $categoriesCell = "categories_list.tpl";        
}             
if (isset($_GET['Search'])) 
  $pageContentsCell="search_results.tpl";
if (isset($_GET['ProductID']))                    
  $pageContentsCell = "product.tpl";     
if (isset($_GET['CartAction']))
{      
  $pageContentsCell = "shopping_cart.tpl";
  $cartSummaryCell = "blank.tpl";
}      
else   
  $cartSummaryCell="cart_summary.tpl";
// customer accounts functionality
$bo_customer = new BoCustomer();
if ($bo_customer->IsAuthenticated()) 
  $customerLoginOrLogged="customer_logged.tpl";
else    
  $customerLoginOrLogged="customer_login.tpl";
if (isset($_GET['RegisterCustomer']) || isset($_GET['ChangeDetails']))
  $pageContentsCell="customer_details.tpl";
if (isset($_GET['AddOrChangeAddress'])) 
  $pageContentsCell="customer_address.tpl";
if (isset($_GET['AddOrChangeCreditCard']))                                                     
  $pageContentsCell="customer_credit_card.tpl";                                                
$page->assign("customerLoginOrLogged",$customerLoginOrLogged);                                 
$page->assign("cartSummaryCell",$cartSummaryCell);                                                      
$page->assign("pageContentsCell", $pageContentsCell);
$page->assign("categoriesCell", $categoriesCell);
$page->display('index.tpl');
// Load app_bottom which closes the database connection
require_once 'include/app_bottom.php';
?>     
