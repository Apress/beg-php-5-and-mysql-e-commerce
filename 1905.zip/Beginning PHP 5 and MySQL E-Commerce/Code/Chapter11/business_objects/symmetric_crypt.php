<?php                                                                                          
class SymmetricCrypt                                                                           
{                                                                                              
  // Encryption/decryption key                                                                 
  private static $msSecretKey = "From Dusk Till Dawn";                                         
  // The initialization vector                                                                 
  private static $msHexaIv = "c7098adc8d6128b5d4b4f7b2fe7f7f05";                               
  // Use the Rijndael Encryption Algorithm                                                     
  private static $msCipherAlgorithm = MCRYPT_RIJNDAEL_128;                                     
  // Function encrypts plain-text string received as parameter 
  // and returns the result in hexadecimal format
  public static function Encrypt($plainString)
  {                                 
    // pack $hexaIV into a binary string
    $binary_iv = pack("H*", SymmetricCrypt::$msHexaIv);
    // encrypt $source              
    $binary_encrypted_string = mcrypt_encrypt(
                           SymmetricCrypt::$msCipherAlgorithm,
                           SymmetricCrypt::$msSecretKey, 
                           $plainString,
                           MCRYPT_MODE_CBC, 
                           $binary_iv);
    // Convert $binaryEncryptedString to hexadecimal format
    $hexa_encrypted_string = bin2hex($binary_encrypted_string);
    return $hexa_encrypted_string;  
  }                                 
  // Function decrypts hexadecimal string received as parameter
  // and returns the result in hexadecimal format
  public static function Decrypt($encryptedString)
  {                                 
    // pack $hexaIV into a binary string
    $binary_iv = pack("H*", SymmetricCrypt::$msHexaIv);
    // convert string in hexadecimal to byte array
    $binary_encrypted_string = pack("H*", $encryptedString);
    // Decrypt $binaryEncryptedString
    $decrypted_string = mcrypt_decrypt(
                                   SymmetricCrypt::$msCipherAlgorithm,
                                   SymmetricCrypt::$msSecretKey, 
                                   $binary_encrypted_string, 
                                   MCRYPT_MODE_CBC,
                                   $binary_iv);
    return $decrypted_string;       
  }                                 
} //end class                       
?>      