<?php           
// references required external functionality
require_once SITE_ROOT . '/data_objects/do_customer.php';
require_once SITE_ROOT . '/business_objects/password_hasher.php';
require_once SITE_ROOT . '/business_objects/secure_card.php';
// represents credit card details in unencrypted format
class PlainCreditCard
{               
   public $mCardHolder="";
   public $mCardNumber="";
   public $mIssueDate="";
   public $mExpiryDate="";
   public $mIssueNumber="";
   public $mCardType="";
   public $mCardNumberX="";
}               
// business tier class that manages customer accounts functionality
class BoCustomer
{               
   /* private stuff */
   private $mDoCustomer;
   //class constructor
   function __construct()
   {            
     $this->mDoCustomer = new DoCustomer();
   }            
   public function IsAuthenticated()
   {            
     if (!(isset($_SESSION['tshirtshop_customer_id'])))
       return 0;
     else       
       return 1;
   }            
   public function GetCustomerIdPassword($email)
   {            
     $result = $this->mDoCustomer->GetCustomerIdPassword($email);
     return $result;
  }                                                                                                    
  public function AddCustomerAndLogin($name, $email, $password, $phone)                                
  {                                                                                                    
     $customer_id = $this->AddCustomer($name, $email, $password, $phone);                              
     $_SESSION['tshirtshop_customer_id'] = $customer_id;                                               
  }                                                                                                    
  public function AddCustomer($name, $email, $password, $phone)                                        
  {                                                                                                    
     $hashed_password = PasswordHasher::Hash($password);                                               
     $customer_id = $this->mDoCustomer->AddCustomer($name, $email,                                     
                                                $hashed_password, $phone);                             
     return $customer_id;                                                                              
  }                                                                                                    
  public function IsValidUser($email, $password)                                                       
  {                                                                                                    
     $result = $this->GetCustomerIdPassword($email);                                                   
     if (empty($result)) return 2;                                                                     
     $customer_id = $result['customer_id'];                                                            
     $hashed_password = $result['password'];                                                           
     if (PasswordHasher::Hash($password) != $hashed_password)                                          
       return 1;                                                                                       
     else                                                                                              
     {                                                                                                 
       $_SESSION['tshirtshop_customer_id'] = $customer_id;                                             
       return 0;                                                                                       
     }                                                                                                 
  }                                                                                                    
  public function GetCurrentCustomerId()                                                               
  {                                                                                                    
     if ($this->IsAuthenticated())                                                                     
       return $_SESSION['tshirtshop_customer_id'];                                                     
     else                                                                                              
       return 0;                                                                                       
  }                                                                                                    
  public function DestroyCustomerSession()                                                             
  {                                                                                                    
     unset($_SESSION['tshirtshop_customer_id']);                                                       
  }                                                                                                    
  public function UpdateCustomerDetails($customerId, $name, $email,                                    
                                              $password, $phone)                                       
  {                                                                                                    
     $hashed_password = PasswordHasher::Hash($password);                                               
     $this->mDoCustomer->UpdateCustomerDetails($customerId, $name, $email,                             
                                                     $hashed_password, $phone);                        
  }                                                                                                    
  public function UpdateCurrentCustomerDetails($name, $email,                                          
                                                      $password, $phone)                               
  {                                           
     $customer_id = $this->GetCurrentCustomerId();
     $this->UpdateCustomerDetails($customer_id, $name, 
                                      $email, $password, $phone);
  }                                           
  public function GetCurrentCustomer()        
  {                                           
     $customer_id = $this->GetCurrentCustomerId();
     $result = $this->GetCustomer($customer_id);
     return $result;                          
  }                                           
  public function GetCustomer($customerId)    
  {                                           
     $result = $this->mDoCustomer->GetCustomer($customerId);
     return $result;                          
  }                                           
  public function UpdateCurrentAddress($address1, $address2, $city, 
                                             $region, $postalCode, $country)
  {                                           
     $customer_id = $this->GetCurrentCustomerId();
     return $this->mDoCustomer->UpdateAddress($customer_id, $address1, 
                         $address2, $city, $region, $postalCode, $country);
  }                                           
  public function GetPlainCreditCardForCurrentUser()
  {                                           
     $customer_data = $this->GetCurrentCustomer();
     if (!(empty($customer_data['credit_card'])))
       return $this->DecryptCreditCard($customer_data['credit_card']);
     else                                     
       return new PlainCreditCard();          
  }                                           
  public function DecryptCreditCard($encryptedCreditCard)
  {                                           
     $secure_card = new SecureCard();         
     $secure_card->LoadEncryptedDataAndDecrypt($encryptedCreditCard);
     $credit_card = new PlainCreditCard();    
     $credit_card->mCardHolder = $secure_card->GetCardHolder();
     $credit_card->mCardNumber = $secure_card->GetCardNumber();
     $credit_card->mIssueDate = $secure_card->GetIssueDate();
     $credit_card->mExpiryDate = $secure_card->GetExpiryDate();
     $credit_card->mIssueNumber = $secure_card->GetIssueNumber();
     $credit_card->mCardType = $secure_card->GetCardType();
     $credit_card->mCardNumberX = $secure_card->GetCardNumberX();
     return $credit_card;                     
  }                                           
  public function UpdateAddress($customerId, $address1, $address2,                                     
                                     $city, $region, $postalCode, $country)                            
  {                                                                                                    
     return $this->mDoCustomer->UpdateAddress($customerId, $address1,                                  
                        $address2, $city, $region, $postalCode, $country);                             
  }                                                                                                    
  public function UpdateCurrentCreditCard($plainCreditCard)                                            
  {                                                                                                    
     $customer_id = $this->GetCurrentCustomerId();                                                     
     $this->UpdateCreditCard($customer_id, $plainCreditCard);                                          
  }                                                                                                    
  public function UpdateCreditCard($customerId, $plainCreditCard)                                      
  {                                                                                                    
     $secure_card = new SecureCard();                                                                  
     $secure_card->LoadPlainDataAndEncrypt($plainCreditCard->mCardHolder,                              
       $plainCreditCard->mCardNumber, $plainCreditCard->mIssueDate,                                    
       $plainCreditCard->mExpiryDate, $plainCreditCard->mIssueNumber,                                  
       $plainCreditCard->mCardType);                                                                   
     $encrypted_card = $secure_card->GetEncryptedData();                                               
     $this->mDoCustomer->UpdateCreditCard($customerId, $encrypted_card);                               
  }                                                                                                    
} //end class                                                                                          
?>          