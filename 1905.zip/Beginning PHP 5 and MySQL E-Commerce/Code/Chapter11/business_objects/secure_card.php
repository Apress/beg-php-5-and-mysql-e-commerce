<?php      
require_once 'symmetric_crypt.php';
// represents a credit card
class SecureCard
{          
  // private members containing credit card's details
  private $mIsDecrypted = false;
  private $mIsEncrypted = false;
  private $mCardHolder;
  private $mCardNumber;
  private $mIssueDate;
  private $mExpiryDate;
  private $mIssueNumber;
  private $mCardType;
  private $mEncryptedData;
  private $mXmlCardData;
  // class constructor
  function __construct()
  {        
    //nothing here
  }        
  // decrypt data
  public function LoadEncryptedDataAndDecrypt($newEncryptedData)
  {        
    $this->mEncryptedData = $newEncryptedData;
    $this->DecryptData();
  }        
  // encrypt data
  public function LoadPlainDataAndEncrypt($newCardHolder, $newCardNumber,
          $newIssueDate, $newExpiryDate, $newIssueNumber, $newCardType)
  {        
    // constructor for use with decrypted data
    $this->mCardHolder = $newCardHolder;
    $this->mCardNumber = $newCardNumber;
    $this->mIssueDate = $newIssueDate;
    $this->mExpiryDate = $newExpiryDate;
    $this->mIssueNumber = $newIssueNumber;
    $this->mCardType = $newCardType;
    $this->EncryptData();
  }        
  // create XML with credit card information                                                   
  private function CreateXml()                                                                 
  {                                                                                            
    // encode card details as XML document                                                     
    $xml_card_data = &$this->mXmlCardData;                                                     
    $xml_card_data = new DOMDocument();                                                        
    $document_root = $xml_card_data->createElement("CardDetails");                             
    $child = $xml_card_data->createElement("CardHolder");                                      
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mCardHolder);                               
    $value = $child->appendChild($value);                                                      
    $child = $xml_card_data->createElement("CardNumber");                                      
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mCardNumber);                               
    $value = $child->appendChild($value);                                                      
    $child = $xml_card_data->createElement("IssueDate");                                       
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mIssueDate);                                
    $value = $child->appendChild($value);                                                      
    $child = $xml_card_data->createElement("ExpiryDate");                                      
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mExpiryDate);                               
    $value = $child->appendChild($value);                                                      
    $child = $xml_card_data->createElement("IssueNumber");                                     
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mIssueNumber);                              
    $value = $child->appendChild($value);                                                      
    $child = $xml_card_data->createElement("CardType");                                        
    $child = $document_root->appendChild($child);                                              
    $value = $xml_card_data->createTextNode($this->mCardType);                                 
    $value = $child->appendChild($value);                                                      
    $document_root = $xml_card_data->appendChild($document_root);                              
  }                                                                                            
  // extract information from XML credit card data                                             
  private function ExtractXml($decryptedData)                                                  
  {                                                                                            
    $xml = simplexml_load_string($decryptedData);                                              
    $this->mCardHolder = (string)$xml->CardHolder;                                             
    $this->mCardNumber = (string)$xml->CardNumber;                                             
    $this->mIssueDate = (string)$xml->IssueDate;                                               
    $this->mExpiryDate = (string)$xml->ExpiryDate;                                             
    $this->mIssueNumber = (string)$xml->IssueNumber;                                           
    $this->mCardType = (string)$xml->CardType;                                                 
  }                                                                                            
  // encrypts the XML credit card data                                                         
  private function EncryptData()                                                               
  {                                        
    // stuff data into XML doc             
    $this->CreateXml();                    
    $this->mEncryptedData = SymmetricCrypt::Encrypt(
                                   $this->mXmlCardData->saveXML());
    $this->mIsEncrypted = true;            
  }                                        
  // decrypts XML credit card data         
  private function DecryptData()           
  {                                        
    // decrypt data                        
    $decrypted_data = SymmetricCrypt::Decrypt($this->mEncryptedData);
    // extract data from XML               
    $this->ExtractXml($decrypted_data);    
    // set decrypted flag                  
    $this->mIsDecrypted = True;            
  }                                        
  // returns credit card holder            
  public function GetCardHolder()          
  {                                        
    if ($this->mIsDecrypted)               
       return $this->mCardHolder;          
    else                                   
       throw new Exception("Data not decrypted");
  }                                        
  // returns credit card number            
  public function GetCardNumber()          
  {                                        
    if ($this->mIsDecrypted)               
       return $this->mCardNumber;          
    else                                   
       throw new Exception("Data not decrypted");
  }                                        
  // returns credit card number with only the last 4 digits
  public function GetCardNumberX()         
  {                                        
    if ($this->mIsDecrypted)               
       return "XXXX-XXXX-XXXX-" . substr($this->mCardNumber, 
                                          strlen($this->mCardNumber) - 4, 4);
    else                                   
       throw new Exception("Data not decrypted");
  }                                        
  // returns credit card issued date                                                           
  public function GetIssueDate()                                                               
  {                                                                                            
    if ($this->mIsDecrypted)                                                                   
       return $this->mIssueDate;                                                               
    else                                                                                       
       throw new Exception("Data not decrypted");                                              
  }                                                                                            
  // returns credit card expiry date                                                           
  public function GetExpiryDate()                                                              
  {                                                                                            
    if ($this->mIsDecrypted)                                                                   
       return $this->mExpiryDate;                                                              
    else                                                                                       
       throw new Exception("Data not decrypted");                                              
  }                                                                                            
  // returns credit card issue number                                                          
  public function GetIssueNumber()                                                             
  {                                                                                            
    if ($this->mIsDecrypted)                                                                   
       return $this->mIssueNumber;                                                             
    else                                                                                       
       throw new Exception("Data not decrypted");                                              
  }                                                                                            
  // returns credit card type                                                                  
  public function GetCardType()                                                                
  {                                                                                            
    if ($this->mIsDecrypted)                                                                   
       return $this->mCardType;                                                                
    else                                                                                       
       throw new Exception("Data not decrypted");                                              
  }                                                                                            
  // returns encrypted version of cc details for database storage                              
  public function GetEncryptedData()                                                           
  {                                                                                            
    if ($this->mIsEncrypted)                                                                   
       return $this->mEncryptedData;                                                           
    else                                                                                       
       throw new Exception("Data not encrypted");                                              
  }                                                                                            
} //end class                                                                                  
?>                                           