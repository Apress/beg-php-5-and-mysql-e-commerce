<?php
/* smarty plugin function that gets called when the
load_customer_credit_card function plugin is loaded from a template */
function smarty_function_load_customer_credit_card($params, $smarty)
{
  $customer_credit_card = new CustomerCreditCard();
  $customer_credit_card->init();
  // assign template variable
  $smarty->assign($params['assign'], $customer_credit_card);
}

class CustomerCreditCard
{
  //public attributes
  public $mTxtCardHolderError;
  public $mTxtCardNumberError;
  public $mTxtExpDateError;
  public $mTxtCardTypesError;
  public $mPlainCreditCard;
  public $mCardTypes;
  //private attributes
  private $mErrors = 0;
  private $mHaveData = 0;
  function __construct()
  {
    $this->mBoCustomer = new BOCustomer();
    $this->mPlainCreditCard = new PlainCreditCard();
    //set form action target
    $this->mActionPage = $_SERVER['REQUEST_URI'];
    //set the return page
    $this->mReturnPage = substr($_SERVER['REQUEST_URI'], 0, strlen
      ($_SERVER['REQUEST_URI']) - strlen("AddOrChangeCreditCard") - 1);
    if (!(empty($_POST['sended'])))
      $this->mHaveData = 1;
    $this->mCardTypes = array('Mastercard' => 'Mastercard', 'Visa' => 'Visa',
      'Mastercard' => 'Mastercard', 'Switch' => 'Switch', 'Solo' => 'Solo',
      'American Express' => 'American Express');
    if ($this->mHaveData == 1)
    {
      //initialisation/validation stuff
      if (empty($_POST['txtCardHolder']))
      {
        $this->mTxtCardHolderError = 1;
        $this->mErrors++;
      }
      else
        $this->mPlainCreditCard->mCardHolder = $_POST['txtCardHolder'];
      if (empty($_POST['txtCardNumber']))
      {
        $this->mTxtCardNumberError = 1;
        $this->mErrors++;
      }
      else
        $this->mPlainCreditCard->mCardNumber = $_POST['txtCardNumber'];
      if (empty($_POST['txtExpDate']))
      {
        $this->mTxtExpDateError = 1;
        $this->mErrors++;
      }
      else
        $this->mPlainCreditCard->mExpiryDate = $_POST['txtExpDate'];
      if (isset($_POST['txtIssueDate']))
        $this->mPlainCreditCard->mIssueDate = $_POST['txtIssueDate'];
      if (isset($_POST['txtIssueNumber']))
        $this->mPlainCreditCard->mIssueNumber = $_POST['txtIssueNumber'];
      $this->mPlainCreditCard->mCardType = $_POST['txtCardType'];
      if (empty($this->mPlainCreditCard->mCardType))
      {
        $this->mTxtCardTypeError = 1;
        $this->mErrors++;
      }
    }
  }
  public function init()
  {
    if ($this->mHaveData == 0)
    {
      //get credit card information
      $this->mPlainCreditCard = $this->mBoCustomer
        ->GetPlainCreditCardForCurrentUser();
    }
    elseif ($this->mErrors == 0)
    {
      //update credit card information
      $this->mBoCustomer->UpdateCurrentCreditCard($this->mPlainCreditCard);
      header("Location:".$this->mReturnPage);
      exit;
    }
  }
} //end class
?>
