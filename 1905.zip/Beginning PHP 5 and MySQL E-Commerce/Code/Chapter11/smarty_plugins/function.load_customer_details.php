<?php
/* smarty plugin function that gets called when the
load_customer_details function plugin is loaded from a template */
function smarty_function_load_customer_details($params, $smarty)
{
  $customer_details = new CustomerDetails();
  $customer_details->init();
  // assign template variable
  $smarty->assign($params['assign'], $customer_details);
}
class CustomerDetails 
{
//public attributes
public $mEditMode=0;
public $mReturnPage;
public $mName;
public $mPhone;
public $mEmail;
public $mTxtNameError=0;
public $mTxtEmailError=0;
public $mTxtPasswordError=0;
public $mTxtPasswordConfirmError=0;
public $mPasswordMatchError=0;
public $mTxtPhoneError=0;
public $mEmailAlreadyTaken=0;
//private attributes
private $mErrors=0;


private $mBoCustomer;
private $mHaveData=0;
//class constructor
function __construct()
{  			   
  $this->mBoCustomer = new BOCustomer();
  //check if we have new user or editing existing customer details
  if ($this->mBoCustomer->IsAuthenticated()) $this->mEditMode=1; 
  $this->mActionPage = $_SERVER['REQUEST_URI'];
  $this->mReturnPage= substr($_SERVER['REQUEST_URI'],0,strlen($_SERVER['REQUEST_URI'])-strlen("ChangeDetails")-1);                 
  //check if we have submitted data 
  if (isset($_POST['sended'])) $this->mHaveData=1;
  if ($this->mHaveData==1)
   {       
      //name cannot be empty
      if (empty($_POST['txtName'])) 
      {
       $this->mTxtNameError=1;
       $this->mErrors++;
      } else $this->mName=$_POST['txtName'];
      if ($this->mEditMode ==0 && empty($_POST['txtEmail']))
      {      
       $this->mTxtEmailError=1;
       $this->mErrors++;
      } else $this->mEmail=$_POST['txtEmail'];     
      //password cannot be empty
      if (empty($_POST['txtPassword']))
      {
       $this->mTxtPasswordError=1;
       $this->mErrors++;
      } else $this->mPassword=$_POST['txtPassword']; 
      //password confirm cannot be empty 
      if (empty($_POST['txtPasswordConfirm']))
      {
       $this->mTxtPasswordConfirmError=1;
       $this->mErrors++;
      } else $password_confirm=$_POST['txtPasswordConfirm'];
      //password and password confirm should be the same 
      if (!isset($password_confirm) || $this->mPassword != $password_confirm)
      {
       $this->mPasswordMatchError=1;
       $this->mErrors++;
      }    
      //phone cannot be empty
      if (empty($_POST['txtPhone']))
      {
        $this->mTxtPhoneError=1;
        $this->mErrors++;
      } else $this->mPhone=$_POST['txtPhone']; 
   }
}
public function init()
{ 
  //if we have submitted data and no errors in submitted data 
  if (($this->mHaveData==1) && ($this->mErrors==0))  
  {
    //check if we have any customer with submitted email ...         
    $customer_read=$this->mBoCustomer->GetCustomerIdPassword($this->mEmail);
    //.. if we have one and we are in 'new user' mode then email already taken error
    if ((!(empty($customer_read))) && ($this->mEditMode==0)) 
    {
      $this->mEmailAlreadyTaken=1;
      return;
    }       
    //we have a new user or we are updating an exisiting user details
    if ($this->mEditMode==0) $this->mBoCustomer->AddCustomerAndLogin($this->mName,$this->mEmail,$this->mPassword,$this->mPhone);
                        else $this->mBoCustomer->UpdateCurrentCustomerDetails($this->mName,$this->mEmail,$this->mPassword,$this->mPhone); 
    //redirect
    if (isset($this->mReturnPage)) 
    {
      header("Location:".$this->mReturnPage);
      exit;
    }            
  }   
  if ($this->mEditMode==1)
  {
  //we are editing an existing customer details
  $customer_data=$this->mBoCustomer->GetCurrentCustomer();           
  $this->mName=$customer_data['name'];
  $this->mEmail=$customer_data['email'];
  $this->mPhone=$customer_data['phone'];              
  }
 }
}//end class
?>