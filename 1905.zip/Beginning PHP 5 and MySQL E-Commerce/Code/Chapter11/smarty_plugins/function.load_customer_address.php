<?php
/* smarty plugin function that gets called when the
load_customer_address function plugin is loaded from a template */
function smarty_function_load_customer_address($params, $smarty)
{
  $customer_address = new CustomerAddress();
  $customer_address->init();
  // assign template variable
  $smarty->assign($params['assign'], $customer_address);
}

class CustomerAddress
{
  //public attributes
  public $mAddress1 = "";
  public $mAddress2 = "";
  public $mTxtAddress1Error = 0;
  public $mCity = "";
  public $mTxtCityError = 0;
  public $mRegion = "";
  public $mTxtRegionError = 0;
  public $mPostalCode = "";
  public $mTxtPostalCodeError = 0;
  public $mCountry = "";
  public $mTxtCountryError = 0;
  public $mBoCustomer;
  public $mReturnPage;
  //private attributes
  private $mErrors = 0;
  private $mHaveData = 0;
  //class constructor
  function __construct()
  {
    $this->mBoCustomer = new BOCustomer();
    $this->mActionPage = $_SERVER['REQUEST_URI'];
    $this->mReturnPage = substr($_SERVER['REQUEST_URI'], 0, strlen
      ($_SERVER['REQUEST_URI']) - strlen("AddOrChangeAddress") - 1);
    if (isset($_POST['sended']))
      $this->mHaveData = 1;
    if ($this->mHaveData == 1)
    {
      //address 1 cannot pe empty
      if (empty($_POST['txtAddress1']))
      {
        $this->mTxtAddress1Error = 1;
        $this->mErrors++;
      }
      else
        $this->mAddress1 = $_POST['txtAddress1'];
      if (isset($_POST['txtAddress2']))
        $this->mAddress2 = $_POST['txtAddress2'];
      if (empty($_POST['txtCity']))
      {
        $this->mTxtCityError = 1;
        $this->mErrors++;
      }
      else
        $this->mCity = $_POST['txtCity'];
      if (empty($_POST['txtRegion']))
      {
        $this->mTxtRegionError = 1;
        $this->mErrors++;
      }
      else
        $this->mRegion = $_POST['txtRegion'];
      if (empty($_POST['txtPostalCode']))
      {
        $this->mTxtPostalCodeError = 1;
        $this->mErrors++;
      }
      else
        $this->mPostalCode = $_POST['txtPostalCode'];
      if (empty($_POST['txtCountry']))
      {
        $this->mTxtCountryError = 1;
        $this->mErrors++;
      }
      else
        $this->mCountry = $_POST['txtCountry'];
    }
  }
  public function init()
  {
    if ($this->mHaveData == 0)
    {
      $customer_data = $this->mBoCustomer->GetCurrentCustomer();
      if (!(empty($customer_data)))
      {
        $this->mAddress1 = $customer_data['address1'];
        $this->mAddress2 = $customer_data['address2'];
        $this->mCity = $customer_data['city'];
        $this->mRegion = $customer_data['region'];
        $this->mPostalCode = $customer_data['postal_code'];
        $this->mCountry = $customer_data['country'];
      }
    }
    elseif ($this->mErrors == 0)
    {
      $this->mBoCustomer->UpdateCurrentAddress($this->mAddress1, $this
        ->mAddress2, $this->mCity, $this->mRegion, $this->mPostalCode, $this
        ->mCountry);
      if (isset($this->mReturnPage))
      {
        header("Location:".$this->mReturnPage);
        exit;
      }
      else
      {
        header("Location:index.php");
        exit;
      }
    }
  }
} //end class
?>
