<?php
/* smarty plugin function that gets called when the
load_customer_logged function plugin is loaded from a template */
function smarty_function_load_customer_logged($params, $smarty)
{
  $customer_logged = new CustomerLogged();
  $customer_logged->init();
  // assign template variable
  $smarty->assign($params['assign'], $customer_logged);
}

class CustomerLogged
{
  //public attributes
  public $mTxtName;
  public $mCreditCardLinkText = "Add Credit Card";
  public $mAddressLinkText = "Add Address";
  public $mReturnAddress;
  public $mLogoutLink;
  public $mChangeDetailsLink;
  public $mAddOrChangeAddressLink;
  //private attributes
  private $mBoCustomer;
  private $mLogout = 0;
  //class constructor
  function __construct()
  {
    $this->mBoCustomer = new BOCustomer();
    if (isset($_GET['Logout']))
      $this->mLogout = 1;
  }
  public function init()
  {
    if ($this->mLogout == 1)
    {
      $this->mBoCustomer->DestroyCustomerSession();
      $redirect = substr($_SERVER['REQUEST_URI'], 0, strlen
        ($_SERVER['REQUEST_URI']) - strlen("Logout=1") - 1);
      header("Location:".$redirect);
      exit;
    }
    $get_vars_no = count($_GET);
    if (isset($_GET['ChangeDetails']))
    {
      $url_base = substr($_SERVER['REQUEST_URI'], 0, strlen
        ($_SERVER['REQUEST_URI']) - strlen("ChangeDetails") - 1);
      $get_vars_no--;
    }
    elseif (isset($_GET['AddOrChangeAddress']))
    {
      $url_base = substr($_SERVER['REQUEST_URI'], 0, strlen
        ($_SERVER['REQUEST_URI']) - strlen("AddOrChangeAddress") - 1);
      $get_vars_no--;
    }
    elseif (isset($_GET['AddOrChangeCreditCard']))
    {
      $url_base = substr($_SERVER['REQUEST_URI'], 0, strlen
        ($_SERVER['REQUEST_URI']) - strlen("AddOrChangeCreditCard") - 1);
      $get_vars_no--;
    }
    else
      $url_base = $_SERVER['REQUEST_URI'];
    $this->mLogoutLink = $url_base.($get_vars_no == 0 ? "?" : "&")."Logout=1";
    $this->mChangeDetailsLink = $url_base.($get_vars_no == 0 ? "?" : "&").
      "ChangeDetails";
    $this->mAddOrChangeAddressLink = $url_base.($get_vars_no == 0 ? "?" : "&").
      "AddOrChangeAddress";
    $this->mAddOrChangeCreditCardLink = $url_base.($get_vars_no == 0 ? "?" :
      "&")."AddOrChangeCreditCard";
    $customer_data = $this->mBoCustomer->GetCurrentCustomer();
    $this->mTxtName = $customer_data['name'];
    if (!(empty($customer_data['credit_card'])))
      $this->mCreditCardLinkText = "Change Credit Card";
    if (!(empty($customer_data['address1'])))
      $this->mAddressLinkText = "Change Address";
  }
} //end class
?>
