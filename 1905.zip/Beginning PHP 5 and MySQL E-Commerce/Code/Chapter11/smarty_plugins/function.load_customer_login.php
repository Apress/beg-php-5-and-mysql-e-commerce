<?php
/* smarty plugin function that gets called when the
load_customer_login function plugin is loaded from a template */
function smarty_function_load_customer_login($params, $smarty)
{
  $customer_login = new CustomerLogin();
  $customer_login->init();
  // assign template variable
  $smarty->assign($params['assign'], $customer_login);
}

class CustomerLogin
{
  //public stuff
  public $mLabelLoginMessage;
  public $mActionTarget;
  public $mRegisterUser;
  //private stuff
  private $email;
  private $password;
  private $mHaveData = 0;
  private $mBoCustomer;
  //class constructor
  function __construct()
  {
    $this->mBoCustomer = new BoCustomer();
    //decide if we have submitted
    if (isset($_POST['Login']))
      $this->mHaveData = 1;
  }
  public function init()
  {
    $this->mActionTarget = "https://" . $_SERVER['SERVER_NAME'] .
           $_SERVER['REQUEST_URI'];
    $this->mRegisterUser = $_SERVER['REQUEST_URI'] . 
           (empty($_GET) ? "?" : "&") . "RegisterCustomer";
    $this->mRegisterUser = $_SERVER['REQUEST_URI'].(empty($_GET) ? "?" : "&").
      "RegisterCustomer";
    if ($this->mHaveData)
    {
      //get login status
      $login_status = $this->mBoCustomer->IsValidUser($_POST['txtEmail'],
        $_POST['txtPassword']);
      switch ($login_status)
      {
        case 2:
          $this->mLabelLoginMessage = "Unrecognized Email.";
          break;
        case 1:
          $this->mLabelLoginMessage = "Unrecognized password.";
          break;
        case 0:
          //valid login...redirect
          header("Location:".$this->mActionTarget);
          exit;
      }

    }

  }
} //end class
?>
