<?php                               
if (isset($_GET['mystring']))       
{                                   
  require_once 'include/config.inc.php';                                                       
  require_once SITE_ROOT . '/business_objects/symmetric_crypt.php';                            
  $string = $_GET['mystring'];                                                                 
  echo "The string is: <br/>" . $string;                                                       
  echo"<br/><br/>";                                                                            
  $sc = new SymmetricCrypt();                                                                  
  $encrypted_string = $sc->Encrypt($string);                                                   
  echo "Encrypted string: <br/>" . $encrypted_string;                                          
  echo "<br/><br/>";                                                                           
  $decrypted_string = $sc->Decrypt($encrypted_string);                                         
  Print "Decrypted string:<br/>" . $decrypted_string . "<br/>";                                
}                                                                                              
?>                                                                                             
<br/>                                                                                          
<form action="test_encryption.php">                                                            
Enter string to encrypt: <input type="text" name="mystring"><br/>                              
<input type="submit" value="Encrypt">                                                          
</form>