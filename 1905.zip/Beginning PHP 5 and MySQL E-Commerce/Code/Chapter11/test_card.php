<?php                  
require_once 'include/config.inc.php';
require_once SITE_ROOT . '/business_objects/secure_card.php';
$card_holder = "Mihai Bucica";
$card_number = "123456789";
$expiry_date = "01/04";
$issue_date = "01/01"; 
$issue_number = 100;   
$card_type = "MasterVisa";
echo "<br/>Credit card data:<br/>" 
      . $card_holder . ", " 
      . $card_number . ", " 
      . $issue_date  . ", " 
      . $expiry_date . ", " 
      . $issue_number . ", " 
      . $card_type;    
echo "<br/>";          
$credit_card = new SecureCard();
try                    
{                      
  $credit_card->LoadPlainDataAndEncrypt(
                      $card_holder, $card_number, $issue_date,
                      $expiry_date, $issue_number, $card_type);
  $encrypted_data = $credit_card->GetEncryptedData();
}                      
catch(Exception $e)    
{                      
  echo "<font color='red'>Exception: "
        . $e->getMessage() . "</font>";
  exit;                
}                      
echo "<br/>Encrypted data:<br/>" . $encrypted_data . "<br/>";
$our_card = new SecureCard();
try                    
{                      
  $our_card->LoadEncryptedDataAndDecrypt($encrypted_data);
  echo "<br/>Decrypted data:<br/>" 
        . $our_card->GetCardHolder() . ", " 
        . $our_card->GetCardNumber() . ", " 
        . $our_card->GetIssueDate() . ", " 
        . $our_card->GetExpiryDate() . ", "
        . $our_card->GetIssueNumber() . ", " 
        . $our_card->GetCardType();
}                      
catch(Exception $e)    
{                      
  echo "<font color='red'>Exception: "                                                         
        . $e->getMessage() . "</font>";                                                        
  exit;                                                                                        
}                                                                                              
?>            